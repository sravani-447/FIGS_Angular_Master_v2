import { CommonModule } from '@angular/common';
import * as L from 'leaflet';
import Chart from 'chart.js/auto';
import { AfterViewInit, Component, ElementRef, HostListener, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ServerRequests } from '../../services/ServerRequests';
import { HttpClient } from '@angular/common/http';
import { findLastIndex } from 'lodash';
import { color } from 'html2canvas/dist/types/css/types/color';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';
import { forkJoin, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Component({
  selector: 'app-impact-assessment',
  templateUrl: './impact-assessment.component.html',
  styleUrls: ['./impact-assessment.component.css']
})
export class ImpactAssessmentComponent implements AfterViewInit, OnDestroy {

  @ViewChild('featureChartCanvas') featureChartCanvas?: ElementRef<HTMLCanvasElement>;
  @ViewChild('featureDonutChartCanvas') featureDonutChartCanvas?: ElementRef<HTMLCanvasElement>;
  map!: L.Map;
  showLayers = false;
  geoServerUrl: any;
  layerDetailsArray: any[] = [];
  drawnItems!: L.FeatureGroup;
  drawControl: any;
  expandedNodes: { [key: string]: boolean } = {};
  slider: any = null;  // For side-by-side slider
  layerOpacity: number = 100;  // Opacity slider (0-100%)
  isControlsHidden = false;
  fcdNov2025Visible = false;
  fdsVisible = false;
  lulcVisible = false;
  soilVisible = false;
  selectedLulcYear = 2025;
  lulcYears = [2020, 2021, 2022, 2023, 2024, 2025];
  selectedTimeSeriesLayer = 'LULC';
  timeSeriesLayerOptions = [
    { label: 'FCD', value: 'FCD' },
    { label: 'FDS', value: 'FDS' },
    { label: 'LULC', value: 'LULC' },
    { label: 'Soil', value: 'SOIL' }
  ];
  private activeTimeSeriesLayers: string[] = [];
  stateBoundaryVisible = true;
  selectedBoundaryBorderColor = '#7b235c';
  selectedBoundaryFillColor = '#eef4fb';
  selectedBoundaryBorderWidth = 2;
  selectedBoundaryOpacity = 100;
  selectedResYear: string = 'geojsonReSurvey';  // Year slider

  // NEW: State for checkboxes
  checkedStates: { [key: string]: boolean } = {};

  // Year Range Selection
  baseYear: number = 2016;
  yearRange: number[] = [];
  selectedFromYear: number = 2016;
  selectedToYear: number = 2025;
  private mapResizeObserver?: ResizeObserver;

  // Map View Selection
  mapViewType: string = 'street'; // 'osm' or 'satellite'

  // API and Data properties
  jurisdictionDetails: any[] = [];
  jurisdictionDetailsAssigned: any = {};
  smcDashboardData: any;

  // Dropdowns data
  districtsList: any[] = [];
  subdivisionsList: any[] = [];
  rangesList: any[] = [];
  beatsList: any[] = [];
  jfmcList: any[] = [];
  schemesList: any[] = [];
  isDistrictFilterReady = false;
  isDarkMode: boolean = false;
  // Selected values
  selectedDistrict: string = '';
  selectedSubdivision: string = '';
  selectedRange: string = '';
  selectedBeat: string = '';
  selectedJFMC: string = '';
  selectedScheme: string = '';
  googleStreets: any;
  googleSatellite: any;
  googleHybrid: any;
  activeBaseLayer: L.TileLayer | null = null;
  showBasemapMenu = false;
  activeBaseLayerName: string = '';
  rasterdataonly: boolean = false;
  showDataGrid: boolean = false;
  activeImpactLayer: any;
  fcd: boolean = false;
  showLulcLegend: boolean = false;
  barChart: any;
  lineChart: any;
  featureChart: Chart | null = null;
  featureDonutChart: Chart | null = null;
  showCharts: boolean = false;
  showChangeDetectionLegend: boolean = false;
  selectedLayer: string = '';
  showFeatureInsights: boolean = false;
  featureInsightTitle: string = 'Map Selection';
  featureInsightSubtitle: string = 'Use the pointer tool to inspect a layer';
  selectedFeatureAttributes: Array<{ key: string; value: string }> = [];  
  selectedFeatureNumericData: Array<{ label: string; value: number }> = [];
  staticTableData = [
    { slNo: 1, reference: 'Scrub Land', new: 'Scrub Land', change: 'No Change', area: 4.19 },
    { slNo: 2, reference: 'Open Forest', new: 'Scrub Land', change: 'Open Forest - Scrub Land', area: 838.08 },
    { slNo: 3, reference: 'Moderate Dense Forest', new: 'Scrub Land', change: 'Moderate Dense Forest - Scrub Land', area: 12909.49 },
    { slNo: 4, reference: 'Very Dense Forest', new: 'Scrub Land', change: 'Very Dense Forest - Scrub Land', area: 9907.15 },

    { slNo: 5, reference: 'Scrub Land', new: 'Open Forest', change: 'Scrub Land - Open Forest', area: 120.55 },
    { slNo: 6, reference: 'Open Forest', new: 'Open Forest', change: 'No Change', area: 5420.33 },
    { slNo: 7, reference: 'Moderate Dense Forest', new: 'Open Forest', change: 'Moderate Dense Forest - Open Forest', area: 8450.76 },
    { slNo: 8, reference: 'Very Dense Forest', new: 'Open Forest', change: 'Very Dense Forest - Open Forest', area: 6231.44 },

    { slNo: 9, reference: 'Scrub Land', new: 'Moderate Dense Forest', change: 'Scrub Land - Moderate Dense Forest', area: 98.22 },
    { slNo: 10, reference: 'Open Forest', new: 'Moderate Dense Forest', change: 'Open Forest - Moderate Dense Forest', area: 1560.87 },
    { slNo: 11, reference: 'Moderate Dense Forest', new: 'Moderate Dense Forest', change: 'No Change', area: 17890.66 },
    { slNo: 12, reference: 'Very Dense Forest', new: 'Moderate Dense Forest', change: 'Very Dense Forest - Moderate Dense Forest', area: 4321.19 },

    { slNo: 13, reference: 'Scrub Land', new: 'Very Dense Forest', change: 'Scrub Land - Very Dense Forest', area: 45.67 },
    { slNo: 14, reference: 'Open Forest', new: 'Very Dense Forest', change: 'Open Forest - Very Dense Forest', area: 780.25 },
    { slNo: 15, reference: 'Moderate Dense Forest', new: 'Very Dense Forest', change: 'Moderate Dense Forest - Very Dense Forest', area: 6540.32 },
    { slNo: 16, reference: 'Very Dense Forest', new: 'Very Dense Forest', change: 'No Change', area: 21000.89 }
  ];
  forestChartData = [
    { label: 'Scrub', area23: 35.7, area25: 23658.91 },
    { label: 'Open', area23: 7052.48, area25: 99369.68 },
    { label: 'Moderate', area23: 171432.9, area25: 130013.04 },
    { label: 'Very Dense', area23: 144387.24, area25: 69451.8 }
  ];
  LAYER_CONFIGS: any = {
    'FCD March 2023': {
      title: 'Forest Canopy Density (2023)',
      items: [
        { label: 'Very Dense (>70%)', color: '#1B430C' },
        { label: 'Moderate (40-70%)', color: '#4CAF50' },
        { label: 'Open (10-40%)', color: '#FFEB3B' },
        { label: 'Scrub (<10%)', color: '#F44336' }
      ]
    },
    'LULC Change Detection': {
      title: 'LULC Categories',
      items: [
        { label: 'Tropical Evergreen', color: '#388E3C' },
        { label: 'Agriculture', color: '#FFFF00' },
        { label: 'Waterbody', color: '#0070FF' }
        // ... add others
      ]
    }
  };
  impactLayerList = [
    {
      id: 'fcd_parent',
      text: 'FCD Layers',
      checked: false,  // ✅ Add checked property for parent layer
      children: [
        { id: 'fcd_change', text: 'FCD Change Detection 2020', type: 'FCD', visible: false },
        { id: 'fcd_change', text: 'FCD Change Detection 2021', type: 'FCD', visible: false },
        { id: 'fcd_change', text: 'FCD Change Detection 2022', type: 'FCD', visible: false },
        { id: 'fcd_change', text: 'FCD Change Detection 2023', type: 'FCD', visible: false },
        { id: 'fcd_change', text: 'FCD Change Detection 2024', type: 'FCD', visible: false },
        { id: 'fcd_change', text: 'FCD Change Detection 2025', type: 'FCD', visible: false },

      ]
    },
    {
      id: 'fds_parent',   // ✅ fixed duplicate ID
      text: 'FDS Layers',
      checked: false,  // ✅ Add checked property for parent layer
      children: [
        { id: 'fds_change', text: 'FDS Change Detection 2020', type: 'FDS', visible: false },
        { id: 'fds_change', text: 'FDS Change Detection 2021', type: 'FDS', visible: false },
        { id: 'fds_change', text: 'FDS Change Detection 2022', type: 'FDS', visible: false },
        { id: 'fds_change', text: 'FDS Change Detection 2023', type: 'FDS', visible: false },
        { id: 'fds_change', text: 'FDS Change Detection 2024', type: 'FDS', visible: false },
        { id: 'fds_change', text: 'FDS Change Detection 2025', type: 'FDS', visible: false },
      ]
    },
    {
      id: 'lulc_parent',
      text: 'LULC Layers',
      checked: false,  // ✅ Add checked property for parent layer
      children: [
        { id: 'lulc_change', text: 'LULC Change Detection 2020', type: 'LULC', visible: false },
        { id: 'lulc_change', text: 'LULC Change Detection 2021', type: 'LULC', visible: false },
        { id: 'lulc_change', text: 'LULC Change Detection 2022', type: 'LULC', visible: false },
        { id: 'lulc_change', text: 'LULC Change Detection 2023', type: 'LULC', visible: false },
        { id: 'lulc_change', text: 'LULC Change Detection 2024', type: 'LULC', visible: false },
        { id: 'lulc_change', text: 'LULC Change Detection 2025', type: 'LULC', visible: false },
      ]
    },
    {
      id: 'soil_parent',
      text: 'Soil Layers',
      checked: false,  // ✅ Add checked property for parent layer
      children: [
        { id: 'soil_change', text: 'Soil Moisture Detection', type: 'SOIL', visible: false }
      ]
    }
  ];
   managerTeam: any[] = [
    {
      "id": "j1",
      "text": "Admin Boundary",
      "children": [
        { "parent": "j1", "id": "j1_1", "text": "State Boundary", "layername": "geojsonLayer" },
        { "parent": "j1", "id": "j1_2", "text": "District Boundary", "layername": "geojsonDistrict" },
        { "parent": "j1", "id": "j1_7", "text": "Subdivision Boundary", "layername": "geojsonSubDivision" },
        { "parent": "j1", "id": "j1_6", "text": "Range Boundry", "layername": "geojsonforestRange" },
        { "parent": "j1", "id": "j1_3", "text": "Beat Boundary", "layername": "geojsonBeat" },
        { "parent": "j1", "id": "j1_4", "text": "JFMC Project Boundary Area", "layername": "geojsonJfmc" },
        { "parent": "j1", "id": "j1_5", "text": "Recorded Forest Area", "layername": "geojsonLayerRecorded_forest_area" },
        { "parent": "j1", "id": "j1_6_c", "text": "Compartment Boundary", "layername": "geojsonLayerCompartment_boundary" },
      ]
    },
  {
  "id": "j2",
  "text": "Collected Data",
  "children": [
    {
      "id": "j2_1",
      "text": "Plantation",
      "parent": "j2",
      "children": [
        {
          "id": "j2_1_1",
          "parent": "j2_1",
          "text": "Re-Survey 2020-21",
          "layername": "geojsonReSurvey"
        },
        {
          "id": "j2_1_2",
          "parent": "j2_1",
          "text": "Re-Survey 2021-22",
          "layername": "geojsonReSurvey_21"
        },
        {
          "id": "j2_1_3",
          "parent": "j2_1",
          "text": "Re-Survey 2022-23",
          "layername": "geojsonReSurvey_22"
        },
        {
          "id": "j2_1_4",
          "parent": "j2_1",
          "text": "Re-Survey 2023-24",
          "layername": "geojsonReSurvey_23"
        },
        {
          "id": "j2_1_5",
          "parent": "j2_1",
          "text": "Re-Survey 2024-25",
          "layername": "geojsonReSurvey_24"
        }
      ]
    }
  ]
}
    
      
  ];
  selectedVersionA: any;
  selectedVersionB: any;
  districtListExpanded: boolean = false;
  subUnitSearchQueries: { [layerName: string]: string } = {};
  expandedSubUnits: { [layerName: string]: boolean } = {};
  infomode = false;
  legendData: any[] = [];
  @ViewChild('barCanvas') barCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('pieCanvas') pieCanvas!: ElementRef<HTMLCanvasElement>;
  barData: any[] = [];
  pieData: any[] = [];
  districtsFromLayer: string[] = [];
  selectedDistrictsMap: { [key: string]: boolean } = {};
  districtGeoJsonLayer: any; // Reference to the Leaflet Layer for filtering

  // Add these variables to your class properties
  selectedFeatureProps: any = null; // Holds properties for the list
  previousSelectedLayer: any = null; // Used to reset styling
  originalStyle: any = null; // Stores original color to restore it later
  propertyMap: { [key: string]: string } = {
    'geojsonLayer': 'State_Name',
    'geojsonDistrict': 'District_F',
    'geojsonSubDivision': 'Subdivision',
    'geojsonforestRange': 'Range',
    'geojsonBeat': 'Beat_Name',
    'geojsonJfmc': 'JFMC_Name',
    'geojsonLayerRecorded_forest_area': 'Forest_Type',
    'geojsonLayerCompartment_boundary': 'Comp_No'
  };
  rasterLayerRef: any;
  layerName: string = '';
  currentRasterLayer: any;
  actuallayername: string = '';
  checkedlayer: any;
  activeImpactLayers: any[] = [];
  isYearSelection: boolean = false;
  scrub: string = '';
  openForest: string = '';
  agriculture: string = '';
  denseForest: string = '';
  water: string = '';
  topStatisticCards = [
    { label: 'SCRUB', columns: ['Open/Other Land (ha)'] },
    { label: 'OPEN FOREST', columns: ['Bamboo (ha)', 'Sal (ha)', 'Plantation (ha)'] },
    { label: 'AGRICULTURE', columns: ['Agriculture (ha)'] },
    { label: 'DENSE FOREST', columns: ['Tropical Evergreen (ha)', 'Semi Evergreen (ha)', 'Moist Mixed Deciduous (ha)', 'Mixed Deciduous (ha)'] }
  ];
  collectedDataType = 'Plantation';
  selectedCollectedDataYear = '';
  private activeCollectedDataLayerName = '';
  collectedDataYearOptions = [
    { label: 'Re-Survey 2020-21', layername: 'geojsonReSurvey' },
    { label: 'Re-Survey 2021-22', layername: 'geojsonReSurvey_21' },
    { label: 'Re-Survey 2022-23', layername: 'geojsonReSurvey_22' },
    { label: 'Re-Survey 2023-24', layername: 'geojsonReSurvey_23' },
    { label: 'Re-Survey 2024-25', layername: 'geojsonReSurvey_24' },
    { label: 'Re-Survey 2025-26', layername: 'geojsonReSurvey_25' }
  ];
  enableloader:boolean =false;
  impactlayername:string = '';
  yearsList: any = [];
  private readonly lulcCsvUrl = 'E:\Figs project\Figs Master\Figs Angular\figs_v2.client\src\assets\allgeodata.csv';
  private lulcStatRows: any[] = [];
  availableDataYears: number[] = [];
  dataYearRangeLabel = '';
  graphSummaryRows: Array<{ label: string; value: number }> = [];
  graphTotalArea = 0;
  graphMessage = 'Select a raster layer to calculate WMS statistics.';
  activeRasterGraphLabel = 'LULC';
  private activeRasterLayerName = '';
  private rasterStatsRequestId = 0;
  private rasterSummaryRows: Array<{ label: string; value: number; count: number }> = [];
  private rasterTopStatisticValues: { [label: string]: number } = {};
  private categoryChart: Chart | null = null;
  private timeSeriesChart: Chart | null = null;
  private isApplyingTimeSeriesSelection = false;
  private readonly lulcMetricColumns = [
    'Tropical Evergreen (ha)',
    'Semi Evergreen (ha)',
    'Moist Mixed Deciduous (ha)',
    'Mixed Deciduous (ha)',
    'Open/Other Land (ha)',
    'Bamboo (ha)',
    'Sal (ha)',
    'Rubber (ha)',
    'Teak (ha)',
    'Plantation (ha)',
    'Agriculture (ha)',
    'Urban / Builtup (ha)',
    'Waterbody (ha)'
  ];



  // normalize values
  getHeight(value: number): number {
    const max = 160000;
    return (value / max) * 100;
  }
  chartContainer: any;
  renderer: any;

  constructor(
    private http: HttpClient,
    public service: ServerRequests
  ) {
    this.geoServerUrl = this.service.Geoserver_URl;
  }
  // Maps layer names to their list of unique sub-unit names
  subUnitLists: { [layerName: string]: string[] } = {};

  // Maps layer names to their selection states { 'geojsonDistrict': { 'West': true, 'East': false } }
  subUnitSelections: { [layerName: string]: { [unitName: string]: boolean } } = {};

  // Store references to the actual GeoJSON layers for styling
  adminLayerRefs: { [layerName: string]: any } = {};
  private readonly boundaryLayerNames = ['geojsonDistrict', 'geojsonSubDivision', 'geojsonforestRange', 'geojsonBeat'];
  private loadedBoundaryLayerNames = new Set<string>();
  private readonly hiddenInitialMapLayerNames = new Set([
    'geojsonDistrict',
    'geojsonSubDivision',
    'geojsonforestRange',
    'geojsonBeat',
    'geojsonJfmc'
  ]);

  // Identify which property in the GeoJSON contains the name for each layer type

 

  vectorlayerConfig = [
    { name: 'geojsonLayer', type: 'State_Boundary', color: 'blue', weight: 3 },
    { name: 'geojsonDistrict', type: 'Forest_District', color: 'red', weight: 1.5 },
    { name: 'geojsonBeat', type: 'Forest_beat_148', color: 'green', weight: 1.5 },
    { name: 'geojsonJfmc', type: 'JFMC_Boundary', color: 'yellow', weight: 1.5 },
    { name: 'geojsonLayerRecorded_forest_area', type: 'Total_Forest', color: 'brown', weight: 1.5 },
    { name: 'geojsonLayerCompartment_boundary', type: 'Compartment_Boundary_Working_Circle', color: 'black', weight: 1.5 },
    { name: 'geojsonforestRange', type: 'Forest_Range', color: '#1229da', weight: 2 },
    { name: 'geojsonSubDivision', type: 'Forest_Subdivision', color: '#737ab4', weight: 2 },
    { name: 'geojsonPlantationPreSurvey', type: 'Scatform_presurvey', color: '#0288D1', weight: 0.8 },
    { name: 'geojsonReSurvey', type: 'Scatform_resurvey_2020-21', color: '#d11002', weight: 2 },
    { name: 'geojsonReSurvey_21', type: 'Scatform_resurvey_2021-22', color: '#3602d1', weight: 2 },
    { name: 'geojsonReSurvey_22', type: 'Scatform_resurvey_2022-23', color: '#d1d102', weight: 2 },
    { name: 'geojsonReSurvey_23', type: 'Scatform_resurvey_2023-24', color: '#cd209c', weight: 2 },
    { name: 'geojsonReSurvey_24', type: 'Plantation_Resurvey_2024-25', color: '#0f0210', weight: 2 },
    { name: 'geojsonReSurvey_25', type: 'Gomati_Khowai_West_District_resurvey_2025-2026', color: '#352106', weight: 0.1 },
    { name: 'geojsonAgroforestryPreSurvey', type: 'Agroforestry_Presurvey', color: '#00897B', weight: 0.8 },
    { name: 'geojsonAgroforestryReSurvey', type: 'Agroforestry_Resurvey', color: '#00695C', weight: 0.8 },
    { name: 'geojsonNursery', type: 'Nursury', color: 'orange' },
    { name: 'geojsonLivestock', type: 'Live_stock', color: '#8D6E63' },
    { name: 'geojsonFishery', type: 'Fishery', color: '#0288D1' },
    { name: 'geojsonEcoTourism', type: 'Eco_Tourism', color: '#66BB6A' },
    { name: 'geojsonHomeStay', type: 'Home_Stay', color: '#AB47BC' },
    { name: 'geojsonNTFPCentre', type: 'NTFP_Centre', color: '#EF5350' },
    { name: 'geojsonNCEOutlets', type: 'NCE_Outlets', color: '#26C6DA' },
    { name: 'geojsonPublicFacility', type: 'Public_Facility_Collected', color: '#EC407A' },
    { name: 'geojsonNTFPResourceMap', type: 'NTFP_Resource_Map', color: '#8BC34A', weight: 1 },
    { name: 'FDS_Grid', type: 'FDS_Grid', color: '#000000', weight: 0.2 },
    { name: 'ppa', type: 'PPA_Intersect', color: '#888800', weight: 1 },
    { name: 'geojsonMicrowatershed', type: 'Micro_Watershed', color: '#000000', weight: 0.5 },
    { name: 'geojsonContour', type: 'Contour', color: '#570000', weight: 1 },
    { name: 'geojsonStreams', type: 'Streams', color: 'blue', weight: 1 },
    { name: 'geojsonForestSlopeGrid', type: 'Slope_Status_Grid_Thematic', color: '#A1887F', weight: 0.5 },
    { name: 'geojsonResidentialAreas', type: 'Habitation', color: 'darkred', weight: 1 },
    { name: 'geojsonRoad', type: 'Road', color: '#0000', weight: 1.5 },
    { name: 'geojsonRivers', type: 'Major_Rivers', color: 'navy', weight: 1.5 },
    { name: 'geojsonJFMCLocations', type: 'JFMC_Locations_Phase1', color: 'purple' },
    { name: 'geojsonCheckDam', type: 'Checkdam_Phase1', color: 'teal' },
    { name: 'geojsonBFBPPublicFacility', type: 'Public_Facility', color: 'red' },
    { name: 'geojsonOfficeLocations', type: 'Beat_Office_Locations', color: 'darkblue' },
    { name: 'geojsonBFBPNursery', type: 'Nursury', color: 'orange' },
    { name: 'geojsonEcoParkGardens', type: 'Eco_Park_Gardens', color: '#33691E', weight: 1 },
    { name: 'geojsonAgroforestryPoints', type: 'AgroForestry_Points', color: 'darkgreen' },
    { name: 'geojsonJFMCMicrowatershed', type: 'Micro_Watershed', color: '#000000', weight: 1 },
    { name: 'geojsonJFMCContour', type: 'Contour', color: 'gray', weight: 0.5 },
    { name: 'geojsonJFMCStreams', type: 'Streams', color: 'blue', weight: 1 },
    { name: 'geojsonJFMCRoad', type: 'Road', color: '#0000', weight: 1.5 },
    { name: 'geojsonJFMCRivers', type: 'Rivers', color: 'navy', weight: 1.5 },
    { name: 'geojsonJFMCCheckDam', type: 'Checkdam_Phase2', color: 'teal' },
    { name: 'geojsonJFMCPublicFacility', type: 'Public_Facility', color: 'red' },
    { name: 'geojsonJFMCResidential', type: 'Residential_Area', color: 'darkred', weight: 1 }
  ];
  renderDynamicChart() {
    // 1. Clear previous canvas if any
    const container = this.chartContainer.nativeElement;
    container.innerHTML = '';

    // 2. Create Canvas Element dynamically (No canvas in HTML)
    const canvas = this.renderer.createElement('canvas');
    this.renderer.setAttribute(canvas, 'id', 'dynamicBarChart');
    this.renderer.appendChild(container, canvas);

    // 3. Initialize Chart.js
    new Chart(canvas, {
      type: 'bar',
      data: {
        labels: ['SHG A', 'SHG B', 'SHG C', 'SHG D', 'SHG E'],
        datasets: [{
          label: 'Gradation Value',
          data: [0, 55, 60, 65, 70],
          backgroundColor: [
            'rgba(0,0,0,0)', // SHG A (Empty)
            '#FFC107',       // SHG B (Yellow)
            '#AEEA00',       // SHG C (Lime)
            '#448AFF',       // SHG D (Blue)
            '#00BCD4'        // SHG E (Cyan)
          ],
          barThickness: 35
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            min: 50,
            max: 70,
            ticks: { color: '#666', stepSize: 5 },
            grid: { color: '#1b4d3e' }
          },
          x: {
            ticks: { color: '#666' },
            grid: { display: false }
          }
        }
      }
    });
  }
  // Inside your component class
  // In your component.ts


  calculateHeight(value: number): string {
    const maxValue = 180000; // This matches your Y-axis top value
    if (!value || value <= 0) return '0%';

    // Calculate percentage
    let percentage = (value / maxValue) * 100;

    // Cap it at 100% so it doesn't break the UI
    if (percentage > 100) percentage = 100;

    return percentage + '%';
  }

  ngAfterViewInit(): void {
    this.initMap();
    this.initializeExpandedNodes();
    this.initializeYearRange();
    this.loadWmsLayers(); // Initialize Raster Layers
    this.loadLayerByName('geojsonDistrict');
    this.loadLayerByName('geojsonSubDivision');
    this.loadLayerByName('geojsonforestRange');
    this.loadLayerByName('geojsonBeat');
    this.loadLayerByName('geojsonJfmc');
    this.loadLayerByName('geojsonLayer');
    this.checkedStates['j1_1'] = true;
    this.changeBaseMap('streets');
    this.attachMapResizeObserver();
    this.refreshMapSize();
    this.refreshMapSize(250);
    this.refreshMapSize(800);
  }

  ngOnDestroy(): void {
    this.mapResizeObserver?.disconnect();
  }

  @HostListener('window:resize')
  onWindowResize() {
    this.refreshMapSize();
  }

  private attachMapResizeObserver() {
    const mapElement = document.getElementById('map');
    const observedElement = mapElement?.parentElement || mapElement;
    if (!observedElement || typeof ResizeObserver === 'undefined') return;

    this.mapResizeObserver?.disconnect();
    this.mapResizeObserver = new ResizeObserver(() => this.refreshMapSize());
    this.mapResizeObserver.observe(observedElement);
  }

  private refreshMapSize(delay = 0) {
    setTimeout(() => {
      if (!this.map) return;
      this.map.invalidateSize({ animate: false, pan: false });
    }, delay);
  }
  showTooltip(x: number, y: number, text: string) {
    const tooltip = document.getElementById('chartTooltip');
    if (!tooltip) return;

    tooltip.style.display = 'block';
    tooltip.style.left = x + 10 + 'px';
    tooltip.style.top = y + 10 + 'px';
    tooltip.innerText = text;
  }

  hideTooltip() {
    const tooltip = document.getElementById('chartTooltip');
    if (!tooltip) return;

    tooltip.style.display = 'none';
  }

  // updateCharts(lat: number, lng: number) {
  //   // 🔥 Replace this with real GIS data
  //   const data = {
  //     scrub: Math.floor(Math.random() * 50),
  //     open: Math.floor(Math.random() * 50),
  //     dense: Math.floor(Math.random() * 50)
  //   };

  //   this.drawBarChart(data);
  //   this.drawPieChart(data);
  // }
drawBarChart(data: any[]) {

  const canvas = this.barCanvas.nativeElement;
  const ctx = canvas.getContext('2d')!;
  const W = canvas.width;
  const H = canvas.height;

  ctx.clearRect(0, 0, W, H);

  const labels = data.map(d => d.name);
  const values = data.map(d => d.value);

  const max = Math.max(...values, 1);

  const padding = 30;
  const chartHeight = H - padding - 20;
  const barWidth = 40;
  const gap = 30;

  const colors = ['#2196f3', '#4caf50', '#ff9800', '#9c27b0', '#1b5e20'];

  this.barData = [];

  // axis
  ctx.strokeStyle = '#ccc';
  ctx.beginPath();
  ctx.moveTo(padding, H - padding);
  ctx.lineTo(W - 10, H - padding);
  ctx.stroke();

  values.forEach((val, i) => {

    const height = (val / max) * chartHeight;
    const x = padding + i * (barWidth + gap);
    const y = H - padding - height;

    ctx.fillStyle = colors[i % colors.length];
    ctx.fillRect(x, y, barWidth, height);

    ctx.fillStyle = '#333';
    ctx.font = '12px Arial';
    ctx.textAlign = 'center';

    ctx.fillText(val.toString(), x + barWidth / 2, y - 5);
    ctx.fillText(labels[i], x + barWidth / 2, H - 10);

    this.barData.push({ x, y, width: barWidth, height, label: labels[i], value: val });
  });
}
drawPieChart(data: any[]) {

  const canvas = this.pieCanvas.nativeElement;
  const ctx = canvas.getContext('2d')!;
  const W = canvas.width;
  const H = canvas.height;

  ctx.clearRect(0, 0, W, H);

  const values = data.map(d => d.value);
  const labels = data.map(d => d.name);

  const total = values.reduce((a, b) => a + b, 0);
  if (total === 0) return;

  const cx = W / 2;
  const cy = H / 2;
  const radius = 70;

  const colors = ['#2196f3', '#4caf50', '#ff9800', '#9c27b0', '#1b5e20'];

  let startAngle = 0;
  this.pieData = [];

  values.forEach((val, i) => {

    const slice = (val / total) * 2 * Math.PI;

    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, radius, startAngle, startAngle + slice);
    ctx.closePath();

    ctx.fillStyle = colors[i % colors.length];
    ctx.fill();

    const mid = startAngle + slice / 2;
    const px = cx + Math.cos(mid) * 40;
    const py = cy + Math.sin(mid) * 40;

    ctx.fillStyle = '#fff';
    ctx.font = '11px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(((val / total) * 100).toFixed(0) + '%', px, py);

    this.pieData.push({
      startAngle,
      endAngle: startAngle + slice,
      label: labels[i],
      value: val
    });

    startAngle += slice;
  });
}
  private loadLulcStatistics(): void {
    this.http.get(this.lulcCsvUrl, { responseType: 'text' }).subscribe({
      next: (csvText: string) => {
        this.lulcStatRows = this.parseCsv(csvText);
        this.availableDataYears = this.mergeUniqueOptions(
          this.lulcStatRows.map(row => `${row.Year || ''}`)
        ).map(year => Number(year)).filter(year => !Number.isNaN(year));
        this.dataYearRangeLabel = this.availableDataYears.length
          ? `${this.availableDataYears[0]} - ${this.availableDataYears[this.availableDataYears.length - 1]}`
          : '';

        this.initializeYearRange();
        this.syncCsvFilterOptions();
        this.applyTimeSeriesSelection();
        this.renderImpactStatistics();
      },
      error: () => {
        this.graphMessage = 'Unable to load JFMC LULC statistics from assets.';
        this.renderImpactStatistics();
      }
    });
  }

  private parseCsv(csvText: string): any[] {
    const rows = csvText
      .replace(/^\uFEFF/, '')
      .split(/\r?\n/)
      .filter(line => line.trim().length > 0)
      .map(line => this.parseCsvLine(line));

    const headers = rows.shift() || [];
    return rows.map(row => {
      const record: any = {};
      headers.forEach((header, index) => {
        record[header] = row[index] ?? '';
      });
      return record;
    });
  }

  private parseCsvLine(line: string): string[] {
    const values: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let index = 0; index < line.length; index++) {
      const char = line[index];
      const nextChar = line[index + 1];

      if (char === '"' && nextChar === '"') {
        current += '"';
        index++;
      } else if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }

    values.push(current.trim());
    return values;
  }

  private syncCsvFilterOptions(): void {
    this.districtsList = this.mergeUniqueOptions(
      this.districtsList,
      this.getCsvOptions('District')
    );
    this.updateJfmcAndSchemeOptions();
  }

  private getCsvOptions(fieldName: string, rows = this.getFilteredLulcRows(false)): string[] {
    return this.mergeUniqueOptions(rows.map(row => this.normalizeBoundaryValue(row[fieldName])));
  }

  private updateJfmcAndSchemeOptions(): void {
    const rows = this.getFilteredLulcRows(false);
    this.jfmcList = this.mergeUniqueOptions(
      this.getCsvOptions('JFMC_Name', rows),
      this.getJfmcOptionsFromLayer()
    );
    this.schemesList = this.getCsvOptions('GP_VC', rows);

    if (this.selectedJFMC && !this.jfmcList.some(value => this.sameBoundaryValue(value, this.selectedJFMC))) {
      this.selectedJFMC = '';
    }
    if (this.selectedScheme && !this.schemesList.some(value => this.sameBoundaryValue(value, this.selectedScheme))) {
      this.selectedScheme = '';
    }
  }

  private getFilteredLulcRows(includeJfmcAndScheme = true): any[] {
    return this.lulcStatRows.filter(row => {
      const districtOk = this.selectedDistrict
        ? this.sameBoundaryValue(row.District, this.selectedDistrict)
        : true;
      const subdivisionOk = this.selectedSubdivision
        ? this.sameBoundaryValue(row.Forest_Sub, this.selectedSubdivision)
        : true;
      const rangeOk = this.selectedRange
        ? this.sameBoundaryValue(row.Range, this.selectedRange)
        : true;
      const beatOk = this.selectedBeat
        ? this.sameBoundaryValue(row.Beat, this.selectedBeat)
        : true;
      const jfmcOk = includeJfmcAndScheme && this.selectedJFMC
        ? this.sameBoundaryValue(row.JFMC_Name, this.selectedJFMC)
        : true;
      const schemeOk = includeJfmcAndScheme && this.selectedScheme
        ? this.sameBoundaryValue(row.GP_VC, this.selectedScheme)
        : true;

      return districtOk && subdivisionOk && rangeOk && beatOk && jfmcOk && schemeOk;
    });
  }

  private getSelectedYears(): number[] {
    const fromYear = Math.min(Number(this.selectedFromYear), Number(this.selectedToYear));
    const toYear = Math.max(Number(this.selectedFromYear), Number(this.selectedToYear));
    const years: number[] = [];

    for (let year = fromYear; year <= toYear; year++) {
      years.push(year);
    }

    return years;
  }

  private getLayerMetrics(): Array<{ label: string; columns: string[] }> {
    if (this.selectedTimeSeriesLayer === 'FCD') {
      return [
        { label: 'Very Dense', columns: ['Tropical Evergreen (ha)', 'Semi Evergreen (ha)'] },
        { label: 'Moderate Dense', columns: ['Moist Mixed Deciduous (ha)', 'Mixed Deciduous (ha)'] },
        { label: 'Open Forest', columns: ['Open/Other Land (ha)', 'Bamboo (ha)', 'Sal (ha)'] },
        { label: 'Plantation', columns: ['Rubber (ha)', 'Teak (ha)', 'Plantation (ha)'] }
      ];
    }

    if (this.selectedTimeSeriesLayer === 'FDS') {
      return [
        { label: 'Forest', columns: ['Tropical Evergreen (ha)', 'Semi Evergreen (ha)', 'Moist Mixed Deciduous (ha)', 'Mixed Deciduous (ha)', 'Bamboo (ha)', 'Sal (ha)'] },
        { label: 'Plantation', columns: ['Rubber (ha)', 'Teak (ha)', 'Plantation (ha)'] },
        { label: 'Open/Other Land', columns: ['Open/Other Land (ha)'] },
        { label: 'Agriculture', columns: ['Agriculture (ha)'] },
        { label: 'Urban / Builtup', columns: ['Urban / Builtup (ha)'] },
        { label: 'Waterbody', columns: ['Waterbody (ha)'] }
      ];
    }

    if (this.selectedTimeSeriesLayer === 'SOIL') {
      return [
        { label: 'Open / Exposed Land', columns: ['Open/Other Land (ha)'] },
        { label: 'Agriculture', columns: ['Agriculture (ha)'] },
        { label: 'Urban / Builtup', columns: ['Urban / Builtup (ha)'] },
        { label: 'Waterbody', columns: ['Waterbody (ha)'] },
        { label: 'Forest Cover', columns: ['Tropical Evergreen (ha)', 'Semi Evergreen (ha)', 'Moist Mixed Deciduous (ha)', 'Mixed Deciduous (ha)', 'Bamboo (ha)', 'Sal (ha)'] }
      ];
    }

    return this.lulcMetricColumns.map(column => ({
      label: column.replace(' (ha)', ''),
      columns: [column]
    }));
  }

  private getMetricValue(row: any, columns: string[]): number {
    return columns.reduce((sum, column) => sum + (Number(row[column]) || 0), 0);
  }

  onTimeSeriesControlChange(): void {
    this.activeRasterGraphLabel = `${this.selectedTimeSeriesLayer} Raster`;
    this.applyTimeSeriesSelection();
    this.renderImpactStatistics();
  }

  onJFMCChange(): void {
    this.renderImpactStatistics();
  }

  onSchemeChange(): void {
    this.renderImpactStatistics();
  }

  renderImpactStatistics(): void {
    if (this.activeRasterLayerName) {
      this.renderWmsRasterStatistics();
      return;
    }

    const rows = this.getFilteredLulcRows(true);
    const selectedYears = this.getSelectedYears();
    const metrics = this.getLayerMetrics();
    const rowsByYear = selectedYears.map(year => rows.filter(row => Number(row.Year) === year));
    const totalsByYear = rowsByYear.map(yearRows =>
      yearRows.reduce((sum, row) => sum + metrics.reduce((metricSum, metric) => metricSum + this.getMetricValue(row, metric.columns), 0), 0)
    );

    this.graphSummaryRows = metrics.map(metric => ({
      label: metric.label,
      value: rows.reduce((sum, row) => selectedYears.includes(Number(row.Year)) ? sum + this.getMetricValue(row, metric.columns) : sum, 0)
    })).filter(row => row.value > 0);

    this.graphTotalArea = this.graphSummaryRows.reduce((sum, row) => sum + row.value, 0);
    this.graphMessage = this.lulcStatRows.length
      ? rows.length
        ? ''
        : 'No matching records for the selected filters.'
      : this.graphMessage;

    this.drawImpactCharts(selectedYears, totalsByYear, this.graphSummaryRows);
  }

  private syncGraphModeFromRasterLayer(layerName: string): void {
    const lulcYearMatch = layerName.match(/^LULC_Tripura_November_(\d{4})_v5$/);

    if (lulcYearMatch) {
      const year = Number(lulcYearMatch[1]);
      this.selectedTimeSeriesLayer = 'LULC';
      this.selectedFromYear = year;
      this.selectedToYear = year;
      this.activeRasterGraphLabel = `LULC ${year}`;
      this.activeRasterLayerName = layerName;
      this.renderImpactStatistics();
      return;
    }

    const rasterGraphMap: { [key: string]: { mode: 'FCD' | 'FDS' | 'LULC' | 'SOIL'; label: string } } = {
      geojsonCanopyDensity: { mode: 'FCD', label: 'FCD March 2023' },
      FCDMarch2025: { mode: 'FCD', label: 'FCD March 2025' },
      fdsMapRasterChangeDetection: { mode: 'FCD', label: 'FCD Change Detection' },
      fdsMapRaster: { mode: 'FDS', label: 'FDS Raster' },
      soil_erosion: { mode: 'SOIL', label: 'Soil Erosion Raster' }
    };

    const graphConfig = rasterGraphMap[layerName];
    if (!graphConfig) return;

    this.selectedTimeSeriesLayer = graphConfig.mode;
    this.activeRasterGraphLabel = graphConfig.label;
    this.activeRasterLayerName = layerName;
    this.renderImpactStatistics();
  }

  private renderWmsRasterStatistics(): void {
    const requestId = ++this.rasterStatsRequestId;
    const layerEntry = this.layerDetailsArray.find(item => item.layername === this.activeRasterLayerName);

    if (!layerEntry?.layer?.wmsParams || !this.map) {
      this.graphMessage = 'Unable to find active WMS raster layer for statistics.';
      this.graphSummaryRows = [];
      this.graphTotalArea = 0;
      this.rasterTopStatisticValues = {};
      this.drawImpactCharts(this.getSelectedYears(), this.getSelectedYears().map(() => 0), []);
      return;
    }

    this.graphMessage = `Calculating ${this.activeRasterGraphLabel} statistics from WMS...`;

    const samplePoints = this.getRasterSamplePoints(12, 10);
    const requests = samplePoints.map(point => {
      const latlng = this.map.containerPointToLatLng([point.x, point.y]);
      const url = this.buildWmsFeatureInfoUrl(layerEntry.layer, latlng);
      return this.http.get(url).pipe(
        map((res: any) => this.extractRasterPixelValue(res)),
        catchError(() => of(null))
      );
    });

    forkJoin(requests).subscribe(values => {
      if (requestId !== this.rasterStatsRequestId) return;

      const validValues = values.filter((value): value is number => typeof value === 'number' && Number.isFinite(value));
      const boundsAreaHa = this.getCurrentMapBoundsAreaHa();
      const hectarePerSample = validValues.length ? boundsAreaHa / validValues.length : 0;
      const classTotals = new Map<string, { label: string; count: number; value: number }>();

      validValues.forEach(value => {
        const label = this.getRasterClassLabel(value);
        const current = classTotals.get(label) || { label, count: 0, value: 0 };
        current.count += 1;
        current.value += hectarePerSample;
        classTotals.set(label, current);
      });

      this.rasterSummaryRows = Array.from(classTotals.values())
        .sort((a, b) => b.value - a.value)
        .map(row => ({ label: row.label, count: row.count, value: Number(row.value.toFixed(2)) }));
      this.graphSummaryRows = this.rasterSummaryRows.map(row => ({ label: row.label, value: row.value }));
      this.graphTotalArea = Number(this.graphSummaryRows.reduce((sum, row) => sum + row.value, 0).toFixed(2));
      this.rasterTopStatisticValues = this.buildRasterTopStatisticValues(this.graphSummaryRows);
      this.graphMessage = validValues.length
        ? ''
        : `No WMS pixel values returned for ${this.activeRasterGraphLabel}.`;

      const selectedYears = this.getSelectedYears();
      const totalsByYear = selectedYears.map(() => this.graphTotalArea);
      this.drawImpactCharts(selectedYears, totalsByYear, this.graphSummaryRows);
    });
  }

  private getRasterSamplePoints(columns: number, rows: number): Array<{ x: number; y: number }> {
    const size = this.map.getSize();
    const points: Array<{ x: number; y: number }> = [];
    const xStep = size.x / columns;
    const yStep = size.y / rows;

    for (let column = 0; column < columns; column++) {
      for (let row = 0; row < rows; row++) {
        points.push({
          x: Math.floor(column * xStep + xStep / 2),
          y: Math.floor(row * yStep + yStep / 2)
        });
      }
    }

    return points;
  }

  private extractRasterPixelValue(response: any): number | null {
    const props = response?.features?.[0]?.properties;
    if (!props) return null;

    const preferredKeys = ['GRAY_INDEX', 'GRAY_INDEX_1', 'PALETTE_INDEX', 'Band1', 'band1', 'value', 'VALUE', 'grid_code', 'DN'];
    for (const key of preferredKeys) {
      const value = Number(props[key]);
      if (Number.isFinite(value)) return value;
    }

    const firstNumericValue = Object.values(props).find(value => Number.isFinite(Number(value)));
    return firstNumericValue === undefined ? null : Number(firstNumericValue);
  }

  private getRasterClassLabel(value: number): string {
    const rounded = Math.round(value);

    if (this.selectedTimeSeriesLayer === 'FCD') {
      const fcdLabels: { [key: number]: string } = {
        1: 'Scrub',
        2: 'Open Forest',
        3: 'Moderate Dense Forest',
        4: 'Dense Forest',
        5: 'Very Dense Forest'
      };
      return fcdLabels[rounded] || `FCD Class ${rounded}`;
    }

    if (this.selectedTimeSeriesLayer === 'FDS') {
      const fdsLabels: { [key: number]: string } = {
        1: 'Non Forest',
        2: 'Open Forest',
        3: 'Dense Forest'
      };
      return fdsLabels[rounded] || `FDS Class ${rounded}`;
    }

    if (this.selectedTimeSeriesLayer === 'SOIL') {
      const soilLabels: { [key: number]: string } = {
        1: 'Low Erosion',
        2: 'Moderate Erosion',
        3: 'High Erosion',
        4: 'Very High Erosion'
      };
      return soilLabels[rounded] || `Soil Class ${rounded}`;
    }

    const lulcLabels: { [key: number]: string } = {
      1: 'Tropical Evergreen',
      2: 'Semi Evergreen',
      3: 'Moist Mixed Deciduous',
      4: 'Mixed Deciduous',
      5: 'Open/Other Land',
      6: 'Bamboo',
      7: 'Sal',
      8: 'Rubber',
      9: 'Teak',
      10: 'Plantation',
      11: 'Agriculture',
      12: 'Urban / Builtup',
      13: 'Waterbody'
    };
    return lulcLabels[rounded] || `LULC Class ${rounded}`;
  }

  private buildRasterTopStatisticValues(rows: Array<{ label: string; value: number }>): { [label: string]: number } {
    const values: { [label: string]: number } = {
      SCRUB: 0,
      'OPEN FOREST': 0,
      AGRICULTURE: 0,
      'DENSE FOREST': 0
    };

    rows.forEach(row => {
      const label = row.label.toLowerCase();
      if (label.includes('scrub') || label.includes('open/other')) {
        values['SCRUB'] += row.value;
      } else if (label.includes('open forest')) {
        values['OPEN FOREST'] += row.value;
      } else if (label.includes('agriculture')) {
        values['AGRICULTURE'] += row.value;
      } else if (label.includes('dense') || label.includes('evergreen') || label.includes('deciduous') || label.includes('forest cover')) {
        values['DENSE FOREST'] += row.value;
      }
    });

    Object.keys(values).forEach(key => {
      values[key] = Number(values[key].toFixed(2));
    });

    return values;
  }

  private getCurrentMapBoundsAreaHa(): number {
    const bounds = this.map.getBounds();
    const northWest = bounds.getNorthWest();
    const northEast = bounds.getNorthEast();
    const southWest = bounds.getSouthWest();
    const widthMeters = northWest.distanceTo(northEast);
    const heightMeters = northWest.distanceTo(southWest);
    return (widthMeters * heightMeters) / 10000;
  }

  getTopStatisticValue(card: { label: string; columns?: string[]; keys?: string[] }): number {
    if (this.activeRasterLayerName) {
      return this.rasterTopStatisticValues[card.label] || 0;
    }

    const selectedYears = this.getSelectedYears();
    const rows = this.getFilteredLulcRows(true);

    if (card.columns?.length) {
      return rows.reduce((sum, row) => {
        if (!selectedYears.includes(Number(row.Year))) return sum;
        return sum + this.getMetricValue(row, card.columns || []);
      }, 0);
    }

    return (card.keys || []).reduce((sum, key) => {
      const row = this.graphSummaryRows.find(item => item.label.toLowerCase() === key.toLowerCase());
      return sum + (row?.value || 0);
    }, 0);
  }

  downloadChartReport(): void {
    const doc = new jsPDF('landscape');
    const generatedOn = new Date().toLocaleString();
    const selectedFilters = [
      ['District', this.selectedDistrict || 'All'],
      ['Subdivision', this.selectedSubdivision || 'All'],
      ['Range', this.selectedRange || 'All'],
      ['Beat', this.selectedBeat || 'All'],
      ['JFMC', this.selectedJFMC || 'All'],
      ['Layer', this.selectedTimeSeriesLayer || '-'],
      ['Year Range', `${this.selectedFromYear} - ${this.selectedToYear}`]
    ];

    doc.setFontSize(18);
    doc.setTextColor(27, 94, 32);
    doc.text('Impact Assessment Chart Report', 14, 16);

    doc.setFontSize(10);
    doc.setTextColor(90);
    doc.text(`Generated: ${generatedOn}`, 14, 23);

    autoTable(doc, {
      startY: 30,
      head: [['Filter', 'Value']],
      body: selectedFilters,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [37, 99, 235] },
      theme: 'grid',
      tableWidth: 120
    });

    const topStatRows = this.topStatisticCards.map(card => [
      card.label,
      `${this.formatReportNumber(this.getTopStatisticValue(card))} ha`
    ]);

    autoTable(doc, {
      startY: 30,
      margin: { left: 150 },
      head: [['Class', 'Area']],
      body: topStatRows,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [27, 94, 32] },
      theme: 'grid',
      tableWidth: 120
    });

    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text(`Total Area: ${this.formatReportNumber(this.graphTotalArea)} ha`, 14, 98);

    const summaryRows = this.graphSummaryRows.length
      ? this.graphSummaryRows.map(row => [row.label, `${this.formatReportNumber(row.value)} ha`])
      : [['No data', this.graphMessage || 'No matching records']];

    autoTable(doc, {
      startY: 104,
      head: [['Category', 'Area']],
      body: summaryRows,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [45, 106, 79] },
      theme: 'striped',
      tableWidth: 120
    });

    const barCanvas = this.barCanvas?.nativeElement;
    const pieCanvas = this.pieCanvas?.nativeElement;

    if (barCanvas) {
      doc.text('Year-wise Area Trend', 150, 98);
      doc.addImage(barCanvas.toDataURL('image/png'), 'PNG', 150, 104, 125, 58);
    }

    if (pieCanvas) {
      doc.text('Category Distribution', 150, 170);
      doc.addImage(pieCanvas.toDataURL('image/png'), 'PNG', 150, 176, 125, 72);
    }

    doc.save(`Impact_Assessment_Chart_Report_${Date.now()}.pdf`);
  }

  private formatReportNumber(value: number): string {
    return Number(value || 0).toLocaleString('en-IN', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    });
  }

  private drawImpactCharts(years: number[], totalsByYear: number[], categoryRows: Array<{ label: string; value: number }>): void {
    if (this.timeSeriesChart) {
      this.timeSeriesChart.destroy();
      this.timeSeriesChart = null;
    }
    if (this.categoryChart) {
      this.categoryChart.destroy();
      this.categoryChart = null;
    }

    const timeSeriesCanvas = this.barCanvas?.nativeElement;
    const categoryCanvas = this.pieCanvas?.nativeElement;
    if (!timeSeriesCanvas || !categoryCanvas) return;

    const palette = ['#1b4332', '#2d6a4f', '#40916c', '#74c69d', '#f4a261', '#277da1', '#577590', '#f94144', '#90be6d', '#f9c74f', '#43aa8b', '#4d908e', '#9c6644'];

    this.timeSeriesChart = new Chart(timeSeriesCanvas, {
      type: 'line',
      data: {
        labels: years.map(year => `${year}`),
        datasets: [{
          label: `${this.activeRasterGraphLabel} area (ha)`,
          data: totalsByYear.map(value => Number(value.toFixed(2))),
          borderColor: '#2563eb',
          backgroundColor: 'rgba(37, 99, 235, 0.15)',
          fill: true,
          tension: 0.28,
          pointRadius: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: true } },
        scales: {
          y: { beginAtZero: true, ticks: { callback: value => `${value}` } },
          x: { ticks: { maxRotation: 0 } }
        }
      }
    });

    this.categoryChart = new Chart(categoryCanvas, {
      type: 'doughnut',
      data: {
        labels: categoryRows.map(row => row.label),
        datasets: [{
          data: categoryRows.map(row => Number(row.value.toFixed(2))),
          backgroundColor: categoryRows.map((_, index) => palette[index % palette.length]),
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: true, position: 'bottom', labels: { boxWidth: 10 } }
        }
      }
    });
  }
  chartbutton() {
    this.showCharts = true;
  }
  initializeExpandedNodes() {
    this.managerTeam.forEach(group => {
      this.expandedNodes[group.id] = true;
    });
  }


  initMap() {
    this.map = L.map('map', {
      zoomControl: false
    }).setView([23.8315, 91.2868], 8);

    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: 'OpenStreetMap'
    });

    this.googleStreets = L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
      maxZoom: 20,
      subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
      attribution: 'Google Streets'
    });

    this.googleSatellite = L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
      maxZoom: 20,
      subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
      attribution: 'Google Satellite'
    });

    osm.addTo(this.map);

    L.control.zoom({ position: 'topright' }).addTo(this.map);
    this.drawnItems = new L.FeatureGroup();
    this.map.addLayer(this.drawnItems);

    this.map.on('draw:created', (e: any) => {
      const layer = e.layer;
      const type = e.layerType;
      if (type === 'polyline') {
        const latlngs = layer.getLatLngs();
        let totalDistance = 0;
        for (let i = 0; i < latlngs.length - 1; i++) {
          totalDistance += latlngs[i].distanceTo(latlngs[i + 1]);
        }
        const distanceKm = (totalDistance / 1000).toFixed(2);
        layer.bindPopup("Distance : " + distanceKm + " km").openPopup();
      }
      if (type === 'polygon') {
        const latlngs = layer.getLatLngs()[0];
        const area = (L as any).GeometryUtil.geodesicArea(latlngs);
        const areaKm = (area / 1000000).toFixed(2);
        layer.bindPopup("Area : " + areaKm + " km²").openPopup();
      }
      this.drawnItems.addLayer(layer);
    });
  }



  loadWmsLayers() {
    const wmsBase = this.geoServerUrl + "/geoserver/cite/wms";
    const wmsLayers = [
      { name: 'fdsMapRaster', layer: 'cite:FDS1' },
      { name: 'geojsonCanopyDensity', layer: 'cite:fcd' },
      { name: 'geojsonStreams', layer: 'cite:Streams' },
      { name: 'lulcLayer', layer: 'cite:lulc' },
      { name: 'soil_erosion', layer: 'cite:Potential_Soil_Erosion' },
      { name: 'demforestslope', layer: 'cite:slope' },
      { name: 'geojsonJFMCVegetationType', layer: 'cite:vegetation_type' },
      { name: 'geojsonJFMCForestCover', layer: 'cite:jfmc_fcd' },
      { name: 'geojsonJFMCLanduse', layer: 'cite:jfmc_lulc' },
      { name: 'FCDMarch2025', layer: 'cite:FCD_March_2025_Final' },
      { name: 'fdsMapRasterChangeDetection', layer: 'cite:FCD_Change_Raster_2003_2005' },
      { name: 'LULC_Tripura_November_2020_v5', layer: 'cite:LULC_Tripura_November_2020_v5' },
      { name: 'LULC_Tripura_November_2021_v5', layer: 'cite:LULC_Tripura_November_2021_v5' },
      { name: 'LULC_Tripura_November_2022_v5', layer: 'cite:LULC_Tripura_November_2022_v5' },
      { name: 'LULC_Tripura_November_2023_v5', layer: 'cite:LULC_Tripura_November_2023_v5' },
      { name: 'LULC_Tripura_November_2024_v5', layer: 'cite:LULC_Tripura_November_2024_v5' },
      { name: 'LULC_Tripura_November_2025_v5', layer: 'cite:LULC_Tripura_November_2025_v5' },
    ];

    wmsLayers.forEach(item => {
      const wmsLayer = L.tileLayer.wms(wmsBase, {
        layers: item.layer,
        format: 'image/png', // Must be PNG for transparency
        transparent: true,   // Tells GeoServer to send transparent background
        styles: '',
        version: '1.1.0',
        maxZoom: 20,
        opacity: 1,
        crossOrigin: true,
        uppercase: true,
        className: 'remove-white-bg' // ADD THIS CLASS
      });

      this.enableWhiteToTransparentTiles(wmsLayer);

      this.layerDetailsArray.push({
        layername: item.name,
        layer: wmsLayer,
      });
    })
  }

  private enableWhiteToTransparentTiles(wmsLayer: L.TileLayer.WMS): void {
    wmsLayer.on('tileload', (event: any) => {
      const tile = event.tile as HTMLImageElement;
      if (!tile || tile.dataset['whiteBgRemoved'] === 'true') return;

      try {
        const canvas = document.createElement('canvas');
        canvas.width = tile.naturalWidth || tile.width;
        canvas.height = tile.naturalHeight || tile.height;

        const context = canvas.getContext('2d', { willReadFrequently: true });
        if (!context || !canvas.width || !canvas.height) return;

        context.drawImage(tile, 0, 0, canvas.width, canvas.height);

        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        const pixels = imageData.data;

        for (let index = 0; index < pixels.length; index += 4) {
          const red = pixels[index];
          const green = pixels[index + 1];
          const blue = pixels[index + 2];
          const isWhite = red > 245 && green > 245 && blue > 245;

          if (isWhite) {
            pixels[index + 3] = 0;
          }
        }

        context.putImageData(imageData, 0, 0);
        tile.dataset['whiteBgRemoved'] = 'true';
        tile.src = canvas.toDataURL('image/png');
      } catch {
        tile.classList.add('remove-white-bg-fallback');
      }
    });
  }


  infoMode = false;

  toggleInfo() {
    this.infoMode = !this.infoMode;

    if (this.infoMode) {
      this.map.getContainer().style.cursor = 'pointer';
      this.map.on('click', this.onMapClick, this);
    } else {
      this.map.getContainer().style.cursor = '';
      this.map.off('click', this.onMapClick, this);
      this.map.closePopup();
    }
  }


  onMapClick(e: any) {
    if (!this.infoMode) return;

    let geoContent = `<b style="color:black">Information</b><br>`;
    let geoFound = false;

    // =========================
    // ✅ 1. GEOJSON
    // =========================
    this.map.eachLayer((layer: any) => {
      if (layer.feature) {

        let isHit = false;

        if (layer.getBounds && layer.getBounds().contains(e.latlng)) {
          isHit = true;
        }

        if (!isHit && layer.getLatLng) {
          const latlng = layer.getLatLng();
          if (latlng.distanceTo(e.latlng) < 20) {
            isHit = true;
          }
        }

        if (isHit) {
          geoFound = true;

          const props = layer.feature.properties || {};
          geoContent += `<b style="color:blue">Layer Info</b><br>`;

          Object.keys(props).forEach(key => {
            if (props[key] != null) {
              geoContent += `<b>${key}:</b> ${props[key]}<br>`;
            }
          });

          geoContent += `<hr>`;
        }
      }
    });

    // =========================
    // ✅ 2. RASTER / WMS (YOUR LAYER)
    // =========================
    const activeWmsLayers = this.getActiveWmsLayerEntries();

    if (!activeWmsLayers.length) {
      if (geoFound) {
        L.popup().setLatLng(e.latlng).setContent(geoContent).openOn(this.map);
      } else {
        this.showLatLngPopup(e);
      }
      return;
    }

    const infoRequests = activeWmsLayers.map(entry => {
      const url = this.buildWmsFeatureInfoUrl(entry.layer, e.latlng);
      return this.http.get(url).pipe(
        map((res: any) => ({ name: entry.layername, res })),
        catchError(() => of({ name: entry.layername, res: null }))
      );
    });

    forkJoin(infoRequests).subscribe((results: any[]) => {
      let rasterFound = false;
      let rasterContent = `<b style="color:green">Raster Info</b><br>`;

      results.forEach(result => {
        if (!result?.res?.features?.length) return;

        rasterFound = true;
        rasterContent += `<b style="color:#14532d">${result.name}</b><br>`;

        result.res.features.forEach((f: any) => {
          const props = f.properties || {};

          Object.keys(props).forEach(key => {
            if (props[key] != null) {
              rasterContent += `<b>${key}:</b> ${props[key]}<br>`;
            }
          });

          rasterContent += `<hr>`;
        });
      });

      let finalContent = '';

      if (geoFound) finalContent += geoContent;
      if (rasterFound) finalContent += rasterContent;

      if (!finalContent) {
        this.showLatLngPopup(e);
        return;
      }

      L.popup()
        .setLatLng(e.latlng)
        .setContent(finalContent)
        .openOn(this.map);
    });
    return;

    const point = this.map.latLngToContainerPoint(e.latlng);
    const size = this.map.getSize();

    const baseUrl = `${this.service.Geoserver_URl}/geoserver/ws_figs/wms`;
    const layerFullName = `ws_figs:${this.actuallayername}`;

    const params: any = {
      service: 'WMS',
      request: 'GetFeatureInfo',
      version: '1.1.1',
      layers: layerFullName,
      query_layers: layerFullName,
      info_format: 'application/json',
      format: 'image/png',
      srs: 'EPSG:4326',
      bbox: this.map.getBounds().toBBoxString(),
      width: size.x,
      height: size.y,
      x: Math.floor(point.x),
      y: Math.floor(point.y)
    };

    // ✅ YEAR FILTER
    if (this.selectedFromYear && this.selectedToYear) {
      params.CQL_FILTER = `yr >= ${this.selectedFromYear} AND yr <= ${this.selectedToYear}`;
    }

    const url = baseUrl + L.Util.getParamString(params);

    // =========================
    // ✅ 3. CALL WMS
    // =========================
    this.http.get(url).subscribe((res: any) => {

      let rasterFound = false;
      let rasterContent = `<b style="color:green">Raster Info</b><br>`;

      if (res?.features?.length) {
        rasterFound = true;

        res.features.forEach((f: any) => {
          const props = f.properties || {};

          Object.keys(props).forEach(key => {
            if (props[key] != null) {
              rasterContent += `<b>${key}:</b> ${props[key]}<br>`;
            }
          });

          rasterContent += `<hr>`;
        });
      }

      // =========================
      // ✅ 4. FINAL MERGE OUTPUT
      // =========================
      let finalContent = '';

      if (geoFound) finalContent += geoContent;
      if (rasterFound) finalContent += rasterContent;

      if (!finalContent) {
        this.showLatLngPopup(e);
        return;
      }

      L.popup()
        .setLatLng(e.latlng)
        .setContent(finalContent)
        .openOn(this.map);

    }, () => {
      // fallback
      if (geoFound) {
        L.popup().setLatLng(e.latlng).setContent(geoContent).openOn(this.map);
      } else {
        this.showLatLngPopup(e);
      }
    });
  }

  private getActiveWmsLayerEntries(): any[] {
    return this.layerDetailsArray.filter(item =>
      item?.layer &&
      this.map.hasLayer(item.layer) &&
      item.layer.wmsParams?.layers &&
      item.layer._url
    );
  }

  private buildWmsFeatureInfoUrl(wmsLayer: any, latlng: L.LatLng): string {
    const point = this.map.latLngToContainerPoint(latlng);
    const size = this.map.getSize();

    const params: any = {
      service: 'WMS',
      request: 'GetFeatureInfo',
      version: '1.1.1',
      layers: wmsLayer.wmsParams.layers,
      query_layers: wmsLayer.wmsParams.layers,
      info_format: 'application/json',
      format: 'image/png',
      transparent: true,
      srs: 'EPSG:4326',
      bbox: this.map.getBounds().toBBoxString(),
      width: size.x,
      height: size.y,
      x: Math.floor(point.x),
      y: Math.floor(point.y)
    };

    return wmsLayer._url + L.Util.getParamString(params);
  }

  showLatLngPopup(e: any) {
    const latlng = e.latlng;

    L.popup()
      .setLatLng(latlng)
      .setContent(`
      <b>Location</b><br>
      Lat: ${latlng.lat.toFixed(5)} <br>
      Lng: ${latlng.lng.toFixed(5)}
    `)
      .openOn(this.map);
  }



  private findClickedVectorFeature(latlng: L.LatLng): { props: any; layer: any; sourceName: string } | null {
    let hitFeature: { props: any; layer: any; sourceName: string } | null = null;

    this.map.eachLayer((layer: any) => {
      if (hitFeature || !layer?.feature) return;

      let isHit = false;

      if (layer.getBounds && layer.getBounds().contains(latlng)) {
        isHit = true;
      } else if (layer.getLatLng) {
        const pointLatLng = layer.getLatLng();
        if (pointLatLng && pointLatLng.distanceTo(latlng) < 30) {
          isHit = true;
        }
      }

      if (isHit) {
        hitFeature = {
          props: layer.feature.properties || {},
          layer,
          sourceName: layer._figsLayerName || 'Feature'
        };
      }
    });

    return hitFeature;
  }

  private parseNumericValue(value: unknown): number | null {
    if (typeof value === 'number' && Number.isFinite(value)) return value;

    if (typeof value === 'string') {
      const cleaned = value.replace(/,/g, '').match(/-?\d+(\.\d+)?/);
      if (!cleaned) return null;

      const parsed = Number(cleaned[0]);
      return Number.isFinite(parsed) ? parsed : null;
    }

    return null;
  }

  private getNumericAttributeData(props: any, latlng?: L.LatLng): Array<{ label: string; value: number }> {
    const numericEntries = Object.entries(props || {})
      .map(([key, value]) => {
        const numericValue = this.parseNumericValue(value);
        return numericValue === null ? null : { label: key.replace(/_/g, ' '), value: numericValue };
      })
      .filter((item): item is { label: string; value: number } => item !== null)
      .slice(0, 6);

    if (numericEntries.length > 0) {
      return numericEntries;
    }

    if (!latlng) {
      return [];
    }

    return [
      { label: 'Latitude', value: Number(latlng.lat.toFixed(5)) },
      { label: 'Longitude', value: Number(latlng.lng.toFixed(5)) }
    ];
  }

  private openFeatureInsight(props: any, sourceName: string, layer: any = null, latlng?: L.LatLng) {
    const cleanedEntries = Object.entries(props || {}).filter(([, value]) => {
      return value !== null && value !== undefined && `${value}`.trim() !== '';
    });

    this.selectedFeatureAttributes = cleanedEntries.map(([key, value]) => ({
      key,
      value: typeof value === 'object' ? JSON.stringify(value) : String(value)
    }));

    this.selectedFeatureNumericData = this.getNumericAttributeData(props, latlng);

    const preferredTitleKeys = [
      'State_Name',
      'District_F',
      'Range',
      'Beat_Name',
      'JFMC_Name',
      'Comp_No',
      'name',
      'Name',
      'id',
      'ID'
    ];

    const titleKey = preferredTitleKeys.find(key => {
      return props?.[key] !== undefined && props?.[key] !== null && `${props[key]}`.trim() !== '';
    });

    this.featureInsightTitle = titleKey ? String(props[titleKey]) : sourceName;
    this.featureInsightSubtitle = latlng
      ? `${sourceName} | ${latlng.lat.toFixed(5)}, ${latlng.lng.toFixed(5)}`
      : sourceName;
    this.selectedFeatureProps = props;
    this.showFeatureInsights = true;
    this.highlightSelectedLayer(layer);
    this.map.closePopup();

    this.scheduleFeatureChartRender();
  }

  private showLocationInsight(latlng: L.LatLng) {
    this.featureInsightTitle = 'Map Location';
    this.featureInsightSubtitle = 'No feature detected at this point';
    this.selectedFeatureAttributes = [
      { key: 'Latitude', value: latlng.lat.toFixed(5) },
      { key: 'Longitude', value: latlng.lng.toFixed(5) }
    ];
    this.selectedFeatureNumericData = this.getNumericAttributeData({}, latlng);
    this.showFeatureInsights = true;
    this.resetSelectedLayerHighlight();
    this.map.closePopup();

    this.scheduleFeatureChartRender();
  }

  private scheduleFeatureChartRender() {
    setTimeout(() => {
      requestAnimationFrame(() => {
        this.renderFeatureInsightChart();
      });
    }, 50);
  }

  private highlightSelectedLayer(layer: any) {
    this.resetSelectedLayerHighlight();

    if (!layer || !layer.setStyle) return;

    this.previousSelectedLayer = layer;
    this.originalStyle = {
      color: layer.options.color,
      weight: layer.options.weight,
      fillColor: layer.options.fillColor,
      fillOpacity: layer.options.fillOpacity,
      opacity: layer.options.opacity
    };

    layer.setStyle({
      color: '#c65e54',
      weight: Math.max((layer.options.weight || 1.5) + 1.5, 3),
      fillColor: layer.options.fillColor || '#c65e54',
      fillOpacity: Math.max(layer.options.fillOpacity || 0.1, 0.2),
      opacity: 1
    });

    if (layer.bringToFront) {
      layer.bringToFront();
    }
  }

  private resetSelectedLayerHighlight() {
    if (this.previousSelectedLayer && this.originalStyle && this.previousSelectedLayer.setStyle) {
      this.previousSelectedLayer.setStyle(this.originalStyle);
    }

    this.previousSelectedLayer = null;
    this.originalStyle = null;
  }

  closeFeatureInsights() {
    this.showFeatureInsights = false;
    this.featureInsightTitle = 'Map Selection';
    this.featureInsightSubtitle = 'Use the pointer tool to inspect a layer';
    this.selectedFeatureAttributes = [];
    this.selectedFeatureNumericData = [];
    this.destroyFeatureInsightChart();
    this.resetSelectedLayerHighlight();
  }

  private destroyFeatureInsightChart() {
    if (this.featureChart) {
      this.featureChart.destroy();
      this.featureChart = null;
    }

    if (this.featureDonutChart) {
      this.featureDonutChart.destroy();
      this.featureDonutChart = null;
    }
  }

  private renderFeatureInsightChart() {
    this.destroyFeatureInsightChart();

    if (this.selectedFeatureNumericData.length === 0) return;

    const canvas =
      this.featureChartCanvas?.nativeElement ||
      (document.getElementById('featureChartCanvas') as HTMLCanvasElement | null);
    const donutCanvas =
      this.featureDonutChartCanvas?.nativeElement ||
      (document.getElementById('featureDonutChartCanvas') as HTMLCanvasElement | null);

    if (!canvas || !donutCanvas) return;

    const chartLabels = this.selectedFeatureNumericData.map(item => item.label);
    const chartValues = this.selectedFeatureNumericData.map(item => item.value);
    const chartColors = ['#2f7d4f', '#4c9a67', '#74a26d', '#b6852d', '#d5a84c', '#7f5a3a'];

    this.featureChart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: chartLabels,
        datasets: [
          {
            label: 'Value',
            data: chartValues,
            borderRadius: 8,
            backgroundColor: chartColors,
            borderWidth: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: {
            ticks: { color: '#4d6453', maxRotation: 0, minRotation: 0 },
            grid: { display: false }
          },
          y: {
            ticks: { color: '#4d6453' },
            grid: { color: 'rgba(47, 125, 79, 0.12)' }
          }
        }
      }
    });

    this.featureDonutChart = new Chart(donutCanvas, {
      type: 'doughnut',
      data: {
        labels: chartLabels,
        datasets: [
          {
            data: chartValues,
            backgroundColor: chartColors,
            borderColor: '#ffffff',
            borderWidth: 2,
            hoverOffset: 6
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              color: '#4d6453',
              boxWidth: 12,
              usePointStyle: true,
              padding: 14
            }
          }
        }
      }
    });
  }

  private getFeatureSourceLabel(layerName: string): string {
    const findNode = (nodes: any[]): any => {
      for (const node of nodes) {
        if (node.layername === layerName) return node;
        if (node.children?.length) {
          const match = findNode(node.children);
          if (match) return match;
        }
      }
      return null;
    };

    const match = findNode(this.managerTeam);
    return match?.text || layerName.replace(/_/g, ' ');
  }

  attachInfoEvent(layer: any, feature: any, sourceName: string = 'Feature') {
    layer.on('click', (e: any) => {

      if (!this.infomode) return;

      // 🚫 Prevent map click from firing
      L.DomEvent.stopPropagation(e);

      const props = feature?.properties || {};

      let content = `<b>Information</b><br>`;

      Object.keys(props).forEach(key => {
        content += `<b>${key}:</b> ${props[key]}<br>`;
      });

      if (Object.keys(props).length === 0) {
        content += 'No data available';
      }

      L.popup()
        .setLatLng(e.latlng)
        .setContent(content)
        .openOn(this.map);
    });
  }

  zoomToExtent() {
    this.map.setView([23.8315, 91.2868], 8);
  }

  setTool(tool: string) {
    if (this.drawControl) {
      this.map.removeControl(this.drawControl);
    }
    if (tool === 'line') {
      this.drawControl = new (L.Control as any).Draw({
        draw: {
          polyline: { shapeOptions: { color: 'red', weight: 4 } },
          polygon: false, rectangle: false, circle: false, marker: false, circlemarker: false
        },
        edit: { featureGroup: this.drawnItems }
      });
      this.map.addControl(this.drawControl);
    }
    if (tool === 'polygon') {
      this.drawControl = new (L.Control as any).Draw({
        draw: {
          polygon: { allowIntersection: false, showArea: true, shapeOptions: { color: 'green' } },
          polyline: false, rectangle: false, circle: false, marker: false, circlemarker: false
        },
        edit: { featureGroup: this.drawnItems }
      });
      this.map.addControl(this.drawControl);
    }
    if (tool === 'pan') {
      this.map.dragging.enable();
    }
  }

  clearDrawings() {
    this.drawnItems.clearLayers();
  }

  toggleSlider(leftLayerName: string = 'geojsonCanopyDensity', rightLayerName: string = 'FCDMarch2025') {
    const leftLayer = this.layerDetailsArray.find(x => x.layername === leftLayerName);
    const rightLayer = this.layerDetailsArray.find(x => x.layername === rightLayerName);
    if (!leftLayer || !rightLayer) return;
    if (this.slider) {
      this.map.removeControl(this.slider);
      this.slider = null;
    }
    if (!this.map.hasLayer(leftLayer.layer)) this.map.addLayer(leftLayer.layer);
    if (!this.map.hasLayer(rightLayer.layer)) this.map.addLayer(rightLayer.layer);

  this.slider = (L as any).control.sideBySide(leftLayer, rightLayer);
  this.slider.addTo(this.map);
     setTimeout(() => {
    this.injectCustomSliderHandle();
  }, 300);

  }
  injectCustomSliderHandle() {
  // Remove existing custom handle if any
  const existing = document.getElementById('custom-slider-handle');
  if (existing) existing.remove();

  const mapContainer = document.getElementById('map');
  if (!mapContainer) return;

  // Create the handle div
  const handle = document.createElement('div');
  handle.id = 'custom-slider-handle';
  handle.innerHTML = `
    <div style="
      width: 44px;
      height: 44px;
      border-radius: 50%;
      background: white;
      border: 2px solid #ccc;
      box-shadow: 0 2px 10px rgba(0,0,0,0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: ew-resize;
      gap: 4px;
    ">
      <div style="width:2px;height:18px;background:#666;border-radius:2px;"></div>
      <div style="width:2px;height:18px;background:#666;border-radius:2px;"></div>
      <div style="width:2px;height:18px;background:#666;border-radius:2px;"></div>
    </div>
  `;

  handle.style.cssText = `
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 1001;
    pointer-events: none;
  `;

  mapContainer.appendChild(handle);

  // Follow the range input position
  this.trackSliderPosition(handle);
}

trackSliderPosition(handle: HTMLElement) {
  const range = document.querySelector('.leaflet-sbs-range') as HTMLInputElement;
  if (!range) return;

  const updatePosition = () => {
    const mapEl = document.getElementById('map');
    if (!mapEl || !range) return;
    const mapWidth = mapEl.offsetWidth;
    const val = parseFloat(range.value);
    const min = parseFloat(range.min) || 0;
    const max = parseFloat(range.max) || 100;
    const percent = (val - min) / (max - min);
    const px = percent * mapWidth;
    handle.style.left = px + 'px';
  };

  updatePosition();
  range.addEventListener('input', updatePosition);
  window.addEventListener('resize', updatePosition);
}
  deactivateSlider() {
    if (this.slider != null) {
      this.slider.remove();
      this.slider = null;
    }
  }

  loadLayerByName(layerName: string) {
    // 1. Check if it is a pre-loaded WMS layer
    this.actuallayername = layerName;
    const existingLayer = this.layerDetailsArray.find(x => x.layername === layerName);
    if (existingLayer) {
      if (!this.map.hasLayer(existingLayer.layer)) this.map.addLayer(existingLayer.layer);
      return;
    }
    this.layerName = layerName;
    // this.actuallayername = existingLayer.text;
    // 2. Otherwise load GeoJSON from config
    const layerConfig = this.vectorlayerConfig.find(l => l.name === layerName);
    if (!layerConfig) return;
    const baseUrl = this.geoServerUrl + "/geoserver/ws_figs/ows";
    const url = `${baseUrl}?service=WFS&version=1.0.0&request=GetFeature&typeName=ws_figs:${encodeURIComponent(layerConfig.type)}&maxFeatures=500000000&srsName=EPSG:4326&outputFormat=application/json`;
    this.loadGeoJson(url, layerConfig.name, { color: layerConfig.color, weight: layerConfig.weight ?? 1.5 });
  }

  // Add these to your class properties

  loadGeoJson(url: string, layerName: string, style: any) {
    this.http.get(url).subscribe({
      next: (res: any) => {
        if (!res || !res.features) return;

        // --- DYNAMIC SUB-UNIT EXTRACTION ---
        const propKey = this.propertyMap[layerName];
        if (propKey) {
          // Extract unique names
          const names = res.features
            .map((f: any) => f.properties[propKey])
            .filter((val: any) => val !== null && val !== undefined);

          this.subUnitLists[layerName] = [...new Set(names)].sort() as string[];

          // Initialize all as checked
          this.subUnitSelections[layerName] = {};
          this.subUnitLists[layerName].forEach(name => {
            this.subUnitSelections[layerName][name] = true;
          });
        }

        const isInitiallyVisible = !this.hiddenInitialMapLayerNames.has(layerName);
        const geoLayer = L.geoJSON(res, {
          style: (feature: any) => ({
            color: style.color || 'blue',
            weight: style.weight || 1,
            fill: false,        // 👈 makes it hollow
            opacity: isInitiallyVisible ? 1 : 0,
            fillOpacity: 0,
            stroke: isInitiallyVisible
          }),
          onEachFeature: (feature: any, layer: any) => {
            (layer as any)._figsLayerName = layerName;

            layer.on('click', (e: any) => {
              L.DomEvent.stop(e);
              this.openFeatureInsight(
                feature?.properties || {},
                this.getFeatureSourceLabel(layerName),
                layer,
                e.latlng
              );
            });
          }

        });

        // Save reference and add to map
        if (propKey) this.adminLayerRefs[layerName] = geoLayer;

        this.layerDetailsArray.push({ layername: layerName, layer: geoLayer });
        this.map.addLayer(geoLayer);

        if (this.boundaryLayerNames.includes(layerName)) {
          this.loadedBoundaryLayerNames.add(layerName);
          if (this.boundaryLayerNames.every(name => this.loadedBoundaryLayerNames.has(name))) {
            this.syncDropdownsFromLoadedLayers();
          }
        }

        if (layerName === 'geojsonJfmc') {
          this.updateJfmcAndSchemeOptions();
        }
      }
    });
  }
  clearCharts() {
    const barCanvas = this.barCanvas?.nativeElement;
    const pieCanvas = this.pieCanvas?.nativeElement;

    if (!barCanvas || !pieCanvas) return;

    const barCtx = barCanvas.getContext('2d');
    const pieCtx = pieCanvas.getContext('2d');

    if (barCtx) {
      barCtx.clearRect(0, 0, barCanvas.width, barCanvas.height);
    }

    if (pieCtx) {
      pieCtx.clearRect(0, 0, pieCanvas.width, pieCanvas.height);
    }
  }
  toggleSubUnitVisibility(layerName: string) {
    const layerRef = this.adminLayerRefs[layerName];
    const propKey = this.propertyMap[layerName];
    const selections = this.subUnitSelections[layerName];

    if (layerRef && propKey && selections) {

      let totalArea = 0;

      layerRef.eachLayer((layer: any) => {
        const props = layer.feature.properties;
        const unitName = props[propKey];
        const isVisible = selections[unitName];

        // ✅ Apply visibility
        layer.setStyle({
          opacity: isVisible ? 1 : 0,
          fillOpacity: isVisible ? 0.1 : 0,
          stroke: isVisible
        });

        if (!isVisible && layer.isPopupOpen()) {
          this.map.closePopup();
        }

        // ✅ Sum selected area
        if (isVisible) {
          totalArea += Number(props.Area_sqkm) || 0;
        }
      });

      // =========================
      // ✅ GET RASTER VALUE
      // =========================
this.enableloader = true;   // START loader BEFORE API call

this.getRasterValue().then((rasterStats: any) => {

  this.enableloader = false;  // STOP loader AFTER response

  if (!rasterStats) {
    return;
  }

  this.scrub = rasterStats[3] || 0;
  this.denseForest = rasterStats[5] || 0;
  this.openForest = rasterStats[2] || 0;
  this.water = rasterStats[1] || 0;
  this.agriculture = rasterStats[4] || 0;

  const chartData = [
    { name: 'Water', value: this.water },
    { name: 'Open Forest', value: this.openForest },
    { name: 'Scrub', value: this.scrub },
    { name: 'Agriculture', value: this.agriculture },
    { name: 'Dense Forest', value: this.denseForest }
  ];

  this.drawBarChart(chartData);
  this.drawPieChart(chartData);

}).catch(() => {
  this.enableloader = false; // STOP loader on error
});
    }
  }

getRasterValue(): Promise<any> {
  return new Promise((resolve) => {

    const bounds = this.map.getBounds();
    const size = this.map.getSize();

    const rasterStats: any = {};

    const step = 20; // sampling resolution (adjust performance vs accuracy)

    const requests: Promise<void>[] = [];

    for (let x = 0; x < size.x; x += step) {
      for (let y = 0; y < size.y; y += step) {

        const latlng = this.map.containerPointToLatLng([x, y]);

        this.map.eachLayer((layer: any) => {

          if (layer._url && layer.wmsParams) {

            const url = `${layer._url}?service=WMS&version=1.1.1&request=GetFeatureInfo
&layers=${layer.wmsParams.layers}
&query_layers=${layer.wmsParams.layers}
&bbox=${bounds.toBBoxString()}
&height=${size.y}
&width=${size.x}
&info_format=application/json
&srs=EPSG:4326
&x=${x}
&y=${y}`;

            const req = this.http.get(url).toPromise()
              .then((res: any) => {

                if (res?.features?.length > 0) {
                  const props = res.features[0].properties;

                  for (const key in props) {
                    if (typeof props[key] === 'number') {
                      const val = props[key];

                      rasterStats[val] = (rasterStats[val] || 0) + 1;
                    }
                  }
                }

              });

            requests.push(req);
          }
        });
      }
    }

    Promise.all(requests).then(() => {
      resolve(rasterStats);
    });

  });
}

  toggleSubUnitDropdown(layerName: string, event: Event) {
    event.stopPropagation();
    this.expandedSubUnits[layerName] = !this.expandedSubUnits[layerName];
  }


  getFilteredUnits(layerName: string): string[] {
    const query = (this.subUnitSearchQueries[layerName] || '').toLowerCase();
    const fullList = this.subUnitLists[layerName] || [];
    if (!query) return fullList;
    return fullList.filter(unit => unit.toLowerCase().includes(query));
  }

  // Initialize search query for a layer
  initSearch(layerName: string) {
    if (!(layerName in this.subUnitSearchQueries)) {
      this.subUnitSearchQueries[layerName] = '';
    }
  }
  // Helper to get keys for the attribute list
  getPropKeys(obj: any) {
    return obj ? Object.keys(obj) : [];
  }
  toggleDistrictExpand(event: Event) {
    event.stopPropagation(); // Prevent the checkbox from triggering
    this.districtListExpanded = !this.districtListExpanded;
  }
  // impact-assessment.component.ts

  // Add/Update this method to handle individual district toggles
  onDistrictCheckboxChange(district: string, event: any) {
    const isChecked = event.target.checked;

    // 1. Update the state map
    this.selectedDistrictsMap[district] = isChecked;

    // 2. Refresh the map layers visibility
    this.toggleDistrictVisibility();
  }

  // Ensure toggleDistrictVisibility is robust
  toggleDistrictVisibility() {
    if (this.districtGeoJsonLayer) {
      this.districtGeoJsonLayer.eachLayer((layer: any) => {
        const districtName = layer.feature.properties.District_F;
        const isVisible = this.selectedDistrictsMap[districtName];

        if (isVisible) {
          layer.setStyle({
            opacity: 1,
            fillOpacity: 0.1,
            stroke: true,
            color: 'red' // or your config color
          });
        } else {
          layer.setStyle({
            opacity: 0,
            fillOpacity: 0,
            stroke: false
          });
          if (layer.isPopupOpen()) this.map.closePopup();
        }
      });
    }
  }

  private normalizeBoundaryValue(value: any): string {
    return (value ?? '').toString().trim();
  }

  private sameBoundaryValue(left: any, right: any): boolean {
    return this.normalizeBoundaryValue(left).toLowerCase() === this.normalizeBoundaryValue(right).toLowerCase();
  }

  private getFeatureValue(props: any, keys: string[]): string {
    if (!props) return '';

    const directKey = keys.find(key => props[key] !== undefined && props[key] !== null && `${props[key]}`.trim() !== '');
    if (directKey) return this.normalizeBoundaryValue(props[directKey]);

    const lowerKeyMap = Object.keys(props).reduce((acc: any, key) => {
      acc[key.toLowerCase()] = props[key];
      return acc;
    }, {});
    const matchedKey = keys.find(key => lowerKeyMap[key.toLowerCase()] !== undefined && `${lowerKeyMap[key.toLowerCase()]}`.trim() !== '');

    return matchedKey ? this.normalizeBoundaryValue(lowerKeyMap[matchedKey.toLowerCase()]) : '';
  }

  private getDistrictValue(props: any): string {
    const value = this.getFeatureValue(props, [
      this.propertyMap['geojsonDistrict'],
      'District_F',
      'Dist_Name',
      'district_name',
      'districtname',
      'District',
      'district'
    ]);
    return value || this.getValueByKeyHint(props, ['dist']);
  }

  private getSubdivisionValue(props: any): string {
    const value = this.getFeatureValue(props, [
      this.propertyMap['geojsonSubDivision'],
      'Sub_Divisi',
      'Sub_Div',
      'Sub_Division',
      'SubDivision',
      'Subdivision',
      'subdivision_name',
      'subdivision'
    ]);
    return value || this.getValueByKeyHint(props, ['sub', 'div']);
  }

  private getRangeValue(props: any): string {
    const value = this.getFeatureValue(props, [
      this.propertyMap['geojsonforestRange'],
      'Range',
      'Range_Name',
      'range_name',
      'rangename',
      'range'
    ]);
    return value || this.getValueByKeyHint(props, ['range']);
  }

  private getBeatValue(props: any): string {
    const value = this.getFeatureValue(props, [
      this.propertyMap['geojsonBeat'],
      'Beat_Name',
      'BeatName',
      'beat_name',
      'beatname',
      'Beat',
      'beat'
    ]);
    return value || this.getValueByKeyHint(props, ['beat']);
  }

  private getJfmcValue(props: any): string {
    const value = this.getFeatureValue(props, [
      this.propertyMap['geojsonJfmc'],
      'JFMC_Name',
      'JFMCName',
      'jfmc_name',
      'jfmcname',
      'JFMC',
      'jfmc'
    ]);
    return value || this.getValueByKeyHint(props, ['jfmc']);
  }

  private getJfmcOptionsFromLayer(): string[] {
    const jfmcLayer = this.adminLayerRefs['geojsonJfmc'];
    if (!jfmcLayer) return [];

    const districtBounds = this.getSelectedDistrictBounds();
    const subdivisionBounds = this.getSelectedSubdivisionBounds();
    const rangeBounds = this.getSelectedRangeBounds();
    const beatBounds = this.getSelectedBeatBounds();

    const filtered = this.collectLayerValues(
      jfmcLayer,
      props => this.getJfmcValue(props),
      (props, layer) => {
        const districtOk = this.selectedDistrict
          ? this.matchesDistrictSelection(props, layer, districtBounds)
          : true;
        const subOk = this.selectedSubdivision
          ? this.matchesSubdivisionSelection(props, layer, subdivisionBounds)
          : true;
        const rangeOk = this.selectedRange
          ? this.matchesRangeSelection(props, layer, rangeBounds)
          : true;
        const beatValue = this.getBeatValue(props);
        const beatOk = this.selectedBeat
          ? (beatValue ? this.sameBoundaryValue(beatValue, this.selectedBeat) : this.isLayerInsideBounds(layer, beatBounds))
          : true;
        return districtOk && subOk && rangeOk && beatOk;
      }
    );

    return filtered.length
      ? filtered
      : this.collectLayerValues(jfmcLayer, props => this.getJfmcValue(props));
  }

  private getValueByKeyHint(props: any, hints: string[]): string {
    if (!props) return '';
    const key = Object.keys(props).find(propKey => {
      const normalizedKey = propKey.toLowerCase().replace(/[^a-z0-9]/g, '');
      return hints.every(hint => normalizedKey.includes(hint));
    });
    return key ? this.normalizeBoundaryValue(props[key]) : '';
  }

  private getJurisdictionRows(): any[] {
    try {
      return JSON.parse(sessionStorage.getItem('jurisdictionDetails') || '[]');
    } catch {
      return [];
    }
  }

  private getJurisdictionValue(row: any, keys: string[]): string {
    return this.getFeatureValue(row, keys);
  }

  private mergeUniqueOptions(...lists: string[][]): string[] {
    const values = new Set<string>();
    lists.flat().forEach(value => {
      const normalized = this.normalizeBoundaryValue(value);
      if (normalized) values.add(normalized);
    });
    return Array.from(values).sort((a, b) => a.localeCompare(b));
  }

  private getJurisdictionSubdivisionsByDistrict(): string[] {
    const rows = this.getJurisdictionRows();
    return rows
      .filter(row => this.sameBoundaryValue(this.getJurisdictionValue(row, ['district_name', 'District_F', 'District', 'district']), this.selectedDistrict))
      .map(row => this.getJurisdictionValue(row, ['subdivision_name', 'Sub_Divisi', 'Sub_Division', 'Subdivision', 'subdivision']));
  }

  private getJurisdictionRanges(): string[] {
    const rows = this.getJurisdictionRows();
    return rows
      .filter(row => {
        const districtOk = this.selectedDistrict
          ? this.sameBoundaryValue(this.getJurisdictionValue(row, ['district_name', 'District_F', 'District', 'district']), this.selectedDistrict)
          : true;
        const subdivisionOk = this.selectedSubdivision
          ? this.sameBoundaryValue(this.getJurisdictionValue(row, ['subdivision_name', 'Sub_Divisi', 'Sub_Division', 'Subdivision', 'subdivision']), this.selectedSubdivision)
          : true;
        return districtOk && subdivisionOk;
      })
      .map(row => this.getJurisdictionValue(row, ['range_name', 'Range_Name', 'Range', 'range']));
  }

  private getJurisdictionBeats(): string[] {
    const rows = this.getJurisdictionRows();
    return rows
      .filter(row => {
        const districtOk = this.selectedDistrict
          ? this.sameBoundaryValue(this.getJurisdictionValue(row, ['district_name', 'District_F', 'District', 'district']), this.selectedDistrict)
          : true;
        const subdivisionOk = this.selectedSubdivision
          ? this.sameBoundaryValue(this.getJurisdictionValue(row, ['subdivision_name', 'Sub_Divisi', 'Sub_Division', 'Subdivision', 'subdivision']), this.selectedSubdivision)
          : true;
        const rangeOk = this.selectedRange
          ? this.sameBoundaryValue(this.getJurisdictionValue(row, ['range_name', 'Range_Name', 'Range', 'range']), this.selectedRange)
          : true;
        return districtOk && subdivisionOk && rangeOk;
      })
      .map(row => this.getJurisdictionValue(row, ['beat_name', 'Beat_Name', 'BeatName', 'Beat', 'beat']));
  }

  private collectLayerValues(layerRef: any, valueGetter: (props: any) => string, filter?: (props: any, layer: any) => boolean): string[] {
    const values = new Set<string>();
    layerRef?.eachLayer((layer: any) => {
      const props = layer?.feature?.properties || {};
      if (filter && !filter(props, layer)) return;
      const value = valueGetter(props);
      if (value) values.add(value);
    });
    return Array.from(values).sort((a, b) => a.localeCompare(b));
  }

  private getFallbackBeatOptions(scope: 'district' | 'subdivision' | 'range'): string[] {
    const beatLayer = this.adminLayerRefs['geojsonBeat'];
    if (!beatLayer) return [];

    const districtBounds = this.getSelectedDistrictBounds();
    const subdivisionBounds = this.getSelectedSubdivisionBounds();
    const rangeBounds = this.getSelectedRangeBounds();

    const scopedValues = this.collectLayerValues(
      beatLayer,
      props => this.getBeatValue(props),
      (props, layer) => {
        const districtOk = this.selectedDistrict
          ? this.matchesDistrictSelection(props, layer, districtBounds)
          : true;
        if (scope === 'district') return districtOk;

        const subOk = this.selectedSubdivision
          ? this.matchesSubdivisionSelection(props, layer, subdivisionBounds)
          : true;
        if (scope === 'subdivision') return districtOk && subOk;

        const rangeOk = this.selectedRange
          ? this.matchesRangeSelection(props, layer, rangeBounds)
          : true;
        return districtOk && subOk && rangeOk;
      }
    );

    return scopedValues.length
      ? scopedValues
      : this.collectLayerValues(beatLayer, props => this.getBeatValue(props));
  }

  private getLayerCenter(layer: any): L.LatLng | null {
    try {
      if (layer?.getBounds) {
        const bounds = layer.getBounds();
        return bounds?.isValid?.() ? bounds.getCenter() : null;
      }
      if (layer?.getLatLng) return layer.getLatLng();
    } catch { }
    return null;
  }

  private getMatchingBounds(layerName: string, predicate: (props: any, layer: any) => boolean): L.LatLngBounds | null {
    const layerRef = this.adminLayerRefs[layerName];
    const bounds = L.latLngBounds([]);

    layerRef?.eachLayer((layer: any) => {
      const props = layer?.feature?.properties || {};
      if (!predicate(props, layer)) return;

      if (layer?.getBounds) {
        const layerBounds = layer.getBounds();
        if (layerBounds?.isValid?.()) bounds.extend(layerBounds);
      } else {
        const center = this.getLayerCenter(layer);
        if (center) bounds.extend(center);
      }
    });

    return bounds.isValid() ? bounds : null;
  }

  private isLayerInsideBounds(layer: any, bounds: L.LatLngBounds | null): boolean {
    if (!bounds) return false;
    const center = this.getLayerCenter(layer);
    return center ? bounds.contains(center) : false;
  }

  private getSelectedDistrictBounds(): L.LatLngBounds | null {
    if (!this.selectedDistrict) return null;
    return this.getMatchingBounds(
      'geojsonDistrict',
      props => this.sameBoundaryValue(this.getDistrictValue(props), this.selectedDistrict)
    );
  }

  private getSelectedSubdivisionBounds(): L.LatLngBounds | null {
    if (!this.selectedSubdivision) return null;
    return this.getMatchingBounds(
      'geojsonSubDivision',
      (props, layer) => {
        const districtBounds = this.getSelectedDistrictBounds();
        const districtValue = this.getDistrictValue(props);
        const districtOk = districtValue
          ? this.sameBoundaryValue(districtValue, this.selectedDistrict)
          : this.isLayerInsideBounds(layer, districtBounds);

        return districtOk && this.sameBoundaryValue(this.getSubdivisionValue(props), this.selectedSubdivision);
      }
    );
  }

  private getSelectedRangeBounds(): L.LatLngBounds | null {
    if (!this.selectedRange) return null;
    return this.getMatchingBounds(
      'geojsonforestRange',
      (props, layer) => {
        const districtBounds = this.getSelectedDistrictBounds();
        const subdivisionBounds = this.getSelectedSubdivisionBounds();
        const districtValue = this.getDistrictValue(props);
        const subdivisionValue = this.getSubdivisionValue(props);
        const districtOk = districtValue
          ? this.sameBoundaryValue(districtValue, this.selectedDistrict)
          : this.isLayerInsideBounds(layer, districtBounds);
        const subdivisionOk = this.selectedSubdivision
          ? (subdivisionValue ? this.sameBoundaryValue(subdivisionValue, this.selectedSubdivision) : this.isLayerInsideBounds(layer, subdivisionBounds))
          : true;

        return districtOk && subdivisionOk && this.sameBoundaryValue(this.getRangeValue(props), this.selectedRange);
      }
    );
  }

  private getSelectedBeatBounds(): L.LatLngBounds | null {
    if (!this.selectedBeat) return null;
    return this.getMatchingBounds(
      'geojsonBeat',
      (props, layer) => {
        const districtBounds = this.getSelectedDistrictBounds();
        const subdivisionBounds = this.getSelectedSubdivisionBounds();
        const rangeBounds = this.getSelectedRangeBounds();
        const districtOk = this.selectedDistrict
          ? this.matchesDistrictSelection(props, layer, districtBounds)
          : true;
        const subOk = this.selectedSubdivision
          ? this.matchesSubdivisionSelection(props, layer, subdivisionBounds)
          : true;
        const rangeOk = this.selectedRange
          ? this.matchesRangeSelection(props, layer, rangeBounds)
          : true;
        return districtOk && subOk && rangeOk && this.sameBoundaryValue(this.getBeatValue(props), this.selectedBeat);
      }
    );
  }

  private matchesDistrictSelection(props: any, layer: any, districtBounds = this.getSelectedDistrictBounds()): boolean {
    if (!this.selectedDistrict) return false;
    const districtValue = this.getDistrictValue(props);
    return districtValue
      ? this.sameBoundaryValue(districtValue, this.selectedDistrict)
      : this.isLayerInsideBounds(layer, districtBounds);
  }

  private matchesSubdivisionSelection(props: any, layer: any, subdivisionBounds = this.getSelectedSubdivisionBounds()): boolean {
    if (!this.selectedSubdivision) return true;
    const subdivisionValue = this.getSubdivisionValue(props);
    return subdivisionValue
      ? this.sameBoundaryValue(subdivisionValue, this.selectedSubdivision)
      : this.isLayerInsideBounds(layer, subdivisionBounds);
  }

  private matchesRangeSelection(props: any, layer: any, rangeBounds = this.getSelectedRangeBounds()): boolean {
    if (!this.selectedRange) return true;
    const rangeValue = this.getRangeValue(props);
    return rangeValue
      ? this.sameBoundaryValue(rangeValue, this.selectedRange)
      : this.isLayerInsideBounds(layer, rangeBounds);
  }

  private syncDropdownsFromLoadedLayers() {
    const districtLayer = this.adminLayerRefs['geojsonDistrict'];
    const subLayer = this.adminLayerRefs['geojsonSubDivision'];
    const rangeLayer = this.adminLayerRefs['geojsonforestRange'];
    const beatLayer = this.adminLayerRefs['geojsonBeat'];

    if (!districtLayer || !subLayer || !rangeLayer || !beatLayer) return;

    this.districtGeoJsonLayer = districtLayer;
    this.districtsList = this.mergeUniqueOptions(
      this.collectLayerValues(districtLayer, props => this.getDistrictValue(props)),
      this.getCsvOptions('District')
    );
    this.isDistrictFilterReady = true;

    if (this.selectedDistrict) {
      this.onDistrictChange();
    } else {
      this.subdivisionsList = [];
      this.rangesList = [];
      this.beatsList = [];
      this.applyDistrictSubdivisionRangeBeatFilter(false);
    }
  }

  onDistrictChange() {
    if (!this.isDistrictFilterReady) return;

    this.selectedSubdivision = '';
    this.selectedRange = '';
    this.selectedBeat = '';

    if (!this.selectedDistrict) {
      this.subdivisionsList = [];
      this.rangesList = [];
      this.beatsList = [];
      this.applyDistrictSubdivisionRangeBeatFilter();
      this.updateJfmcAndSchemeOptions();
      this.renderImpactStatistics();
      return;
    }

    const districtBounds = this.getSelectedDistrictBounds();

    const layerSubdivisions = this.collectLayerValues(
      this.adminLayerRefs['geojsonSubDivision'],
      props => this.getSubdivisionValue(props),
      (props, layer) => this.matchesDistrictSelection(props, layer, districtBounds)
    );
    const layerRanges = this.collectLayerValues(
      this.adminLayerRefs['geojsonforestRange'],
      props => this.getRangeValue(props),
      (props, layer) => this.matchesDistrictSelection(props, layer, districtBounds)
    );
    const layerBeats = this.collectLayerValues(
      this.adminLayerRefs['geojsonBeat'],
      props => this.getBeatValue(props),
      (props, layer) => this.matchesDistrictSelection(props, layer, districtBounds)
    );

    this.subdivisionsList = this.mergeUniqueOptions(layerSubdivisions, this.getJurisdictionSubdivisionsByDistrict());
    this.rangesList = this.mergeUniqueOptions(layerRanges, this.getJurisdictionRanges());
    this.beatsList = this.mergeUniqueOptions(
      layerBeats.length ? layerBeats : this.getFallbackBeatOptions('district'),
      this.getJurisdictionBeats()
    );

    this.applyDistrictSubdivisionRangeBeatFilter();
    this.updateJfmcAndSchemeOptions();
    this.renderImpactStatistics();
  }

  onSubdivisionChange() {
    if (!this.isDistrictFilterReady) return;

    this.selectedRange = '';
    this.selectedBeat = '';

    if (!this.selectedSubdivision) {
      this.onDistrictChange();
      return;
    }

    const layerRanges = this.collectLayerValues(
      this.adminLayerRefs['geojsonforestRange'],
      props => this.getRangeValue(props),
      (props, layer) => {
        const districtBounds = this.getSelectedDistrictBounds();
        const subdivisionBounds = this.getSelectedSubdivisionBounds();
        const districtOk = this.matchesDistrictSelection(props, layer, districtBounds);
        const subdivisionValue = this.getSubdivisionValue(props);
        const subdivisionOk = subdivisionValue
          ? this.sameBoundaryValue(subdivisionValue, this.selectedSubdivision)
          : this.isLayerInsideBounds(layer, subdivisionBounds);
        return districtOk && subdivisionOk;
      }
    );
    const layerBeats = this.collectLayerValues(
      this.adminLayerRefs['geojsonBeat'],
      props => this.getBeatValue(props),
      (props, layer) => {
        const districtBounds = this.getSelectedDistrictBounds();
        const subdivisionBounds = this.getSelectedSubdivisionBounds();
        const districtOk = this.matchesDistrictSelection(props, layer, districtBounds);
        const subdivisionValue = this.getSubdivisionValue(props);
        const subdivisionOk = subdivisionValue
          ? this.sameBoundaryValue(subdivisionValue, this.selectedSubdivision)
          : this.isLayerInsideBounds(layer, subdivisionBounds);
        return districtOk && subdivisionOk;
      }
    );

    this.rangesList = this.mergeUniqueOptions(layerRanges, this.getJurisdictionRanges());
    this.beatsList = this.mergeUniqueOptions(
      layerBeats.length ? layerBeats : this.getFallbackBeatOptions('subdivision'),
      this.getJurisdictionBeats()
    );

    this.applyDistrictSubdivisionRangeBeatFilter();
    this.updateJfmcAndSchemeOptions();
    this.renderImpactStatistics();
  }

  onRangeChange() {
    if (!this.isDistrictFilterReady) return;

    this.selectedBeat = '';

    if (!this.selectedRange) {
      this.onSubdivisionChange();
      return;
    }

    const layerBeats = this.collectLayerValues(
      this.adminLayerRefs['geojsonBeat'],
      props => this.getBeatValue(props),
      (props, layer) => {
        const districtBounds = this.getSelectedDistrictBounds();
        const subdivisionBounds = this.getSelectedSubdivisionBounds();
        const rangeBounds = this.getSelectedRangeBounds();
        const districtOk = this.matchesDistrictSelection(props, layer, districtBounds);
        const subOk = this.matchesSubdivisionSelection(props, layer, subdivisionBounds);
        const rangeValue = this.getRangeValue(props);
        const rangeOk = rangeValue
          ? this.sameBoundaryValue(rangeValue, this.selectedRange)
          : this.isLayerInsideBounds(layer, rangeBounds);
        return districtOk && subOk && rangeOk;
      }
    );

    this.beatsList = this.mergeUniqueOptions(
      layerBeats.length ? layerBeats : this.getFallbackBeatOptions('range'),
      this.getJurisdictionBeats()
    );

    this.applyDistrictSubdivisionRangeBeatFilter();
    this.updateJfmcAndSchemeOptions();
    this.renderImpactStatistics();
  }

  onBeatChange() {
    if (!this.isDistrictFilterReady) return;
    this.applyDistrictSubdivisionRangeBeatFilter();
    this.updateJfmcAndSchemeOptions();
    this.renderImpactStatistics();
  }

  hasActiveRasterLegend(): boolean {
    return this.fcdNov2025Visible || this.fdsVisible || this.lulcVisible || this.soilVisible;
  }

  private applyDistrictSubdivisionRangeBeatFilter(zoomToSelection = true) {
    const districtLayer = this.adminLayerRefs['geojsonDistrict'];
    const subLayer = this.adminLayerRefs['geojsonSubDivision'];
    const rangeLayer = this.adminLayerRefs['geojsonforestRange'];
    const beatLayer = this.adminLayerRefs['geojsonBeat'];

    if (!districtLayer || !subLayer || !rangeLayer || !beatLayer) return;

    const districtBounds = this.getSelectedDistrictBounds();
    const subdivisionBounds = this.getSelectedSubdivisionBounds();
    const rangeBounds = this.getSelectedRangeBounds();

    districtLayer.eachLayer((layer: any) => {
      const props = layer?.feature?.properties || {};
      const visible = this.selectedDistrict ? this.sameBoundaryValue(this.getDistrictValue(props), this.selectedDistrict) : false;
      layer.setStyle({ color: 'red', opacity: visible ? 1 : 0, fillOpacity: visible ? 0.08 : 0, stroke: visible });
      if (!visible && layer.isPopupOpen?.()) this.map.closePopup();
    });

    subLayer.eachLayer((layer: any) => {
      const props = layer?.feature?.properties || {};
      const districtOk = this.matchesDistrictSelection(props, layer, districtBounds);
      const subOk = this.matchesSubdivisionSelection(props, layer, subdivisionBounds);
      const visible = districtOk && subOk;
      layer.setStyle({ color: '#737ab4', opacity: visible ? 1 : 0, fillOpacity: visible ? 0.05 : 0, stroke: visible });
      if (!visible && layer.isPopupOpen?.()) this.map.closePopup();
    });

    rangeLayer.eachLayer((layer: any) => {
      const props = layer?.feature?.properties || {};
      const districtOk = this.matchesDistrictSelection(props, layer, districtBounds);
      const subOk = this.matchesSubdivisionSelection(props, layer, subdivisionBounds);
      const rangeOk = this.matchesRangeSelection(props, layer, rangeBounds);
      const visible = districtOk && subOk && rangeOk;
      layer.setStyle({ color: '#1229da', opacity: visible ? 1 : 0, fillOpacity: visible ? 0.04 : 0, stroke: visible });
      if (!visible && layer.isPopupOpen?.()) this.map.closePopup();
    });

    beatLayer.eachLayer((layer: any) => {
      const props = layer?.feature?.properties || {};
      const districtOk = this.matchesDistrictSelection(props, layer, districtBounds);
      const subOk = this.matchesSubdivisionSelection(props, layer, subdivisionBounds);
      const rangeOk = this.matchesRangeSelection(props, layer, rangeBounds);
      const beatOk = this.selectedBeat ? this.sameBoundaryValue(this.getBeatValue(props), this.selectedBeat) : true;
      const visible = districtOk && subOk && rangeOk && beatOk;
      layer.setStyle({ color: 'green', opacity: visible ? 1 : 0, fillOpacity: visible ? 0.03 : 0, stroke: visible });
      if (!visible && layer.isPopupOpen?.()) this.map.closePopup();
    });

    if (zoomToSelection) {
      this.zoomToCurrentBoundarySelection();
    }
  }

  private zoomToCurrentBoundarySelection() {
    const preferredLayerName = this.selectedBeat
      ? 'geojsonBeat'
      : this.selectedRange
        ? 'geojsonforestRange'
        : this.selectedSubdivision
          ? 'geojsonSubDivision'
          : this.selectedDistrict
            ? 'geojsonDistrict'
            : '';

    if (!preferredLayerName) return;

    const layerRef = this.adminLayerRefs[preferredLayerName];
    const bounds = L.latLngBounds([]);

    layerRef?.eachLayer((layer: any) => {
      if (layer?.options?.opacity > 0 && layer.getBounds) {
        bounds.extend(layer.getBounds());
      }
    });

    if (bounds.isValid()) {
      this.map.fitBounds(bounds, { padding: [30, 30], maxZoom: 13, animate: true });
    }
  }

  toggleLayerPanel() {
    this.showLayers = !this.showLayers;
  }

  toggleTreeNode(nodeId: string) {
    this.expandedNodes[nodeId] = !this.expandedNodes[nodeId];
  }

  onNodeToggle(event: any, node: any) {
    const isChecked = event.target.checked;
    this.checkedStates[node.id] = isChecked;

    if (node.layername && this.subUnitLists[node.layername]) {
      // 1. Bulk update sub-unit selections
      this.subUnitLists[node.layername].forEach(name => {
        this.subUnitSelections[node.layername][name] = isChecked;
      });

      // 2. Update Map Styling
      this.toggleSubUnitVisibility(node.layername);

      // 3. Zoom to the entire layer extent if parent is checked
      if (isChecked) {
        const layerRef = this.adminLayerRefs[node.layername];
        if (layerRef && this.map.hasLayer(layerRef)) {
          const layerBounds = layerRef.getBounds();
          if (layerBounds.isValid()) {
            this.map.fitBounds(layerBounds, { padding: [20, 20] });
          }
        }
      }
    }

    this.toggleChildrenRecursive(node, isChecked);
  }

  // Individual sub-unit checkbox change
  onSubUnitChange(layerName: string, unitName: string, event: any) {
    const isChecked = event.target.checked;
    this.subUnitSelections[layerName][unitName] = isChecked;
    const layer = this.vectorlayerConfig.find(x => x.name === layerName);
    this.actuallayername = layer?.type || '';

    // 1. Update visibility (your existing logic)
    this.toggleSubUnitVisibility(layerName);

    // 2. Zoom to the area if it was checked
    if (isChecked) {
      this.zoomToSubUnit(layerName, unitName);
      this.updateLayerVisibility(layerName);

    }
  }
  // Select or Deselect ALL units in a layer
  tempAreas: number[] = [];

  toggleAllSubUnits(layerName: string, event: Event) {
    const isSelected = (event.target as HTMLInputElement).checked;

    const units = this.subUnitLists[layerName];
    if (!units) return;

    // ✅ Update selections
    units.forEach(unit => {
      this.subUnitSelections[layerName][unit] = isSelected;
    });

    const layerRef = this.adminLayerRefs[layerName];
    const propKey = this.propertyMap[layerName];
    const selections = this.subUnitSelections[layerName];

    if (!layerRef || !propKey || !selections) return;

    const rasterPromises: Promise<any>[] = [];
    this.tempAreas = [];

    layerRef.eachLayer((layer: any) => {
      const props = layer.feature?.properties || {};
      const unitName = props[propKey];
      const isVisible = selections[unitName];

      // ✅ Apply visibility
      layer.setStyle({
        opacity: isVisible ? 1 : 0,
        fillOpacity: isVisible ? 0.1 : 0,
        stroke: isVisible
      });

      if (isVisible) {
        const area = Number(props.Area_sqkm) || 0;
        const center = layer.getBounds().getCenter();

        this.tempAreas.push(area);

        rasterPromises.push(
          this.getRasterValueAtPoint(center, unitName)
        );
      }
    });

    // =========================
    // ✅ AFTER ALL API CALLS
    // =========================
    Promise.all(rasterPromises).then((results) => {

      const chartArray = results.map((res, i) => ({
        label: res.label,
        area: this.tempAreas[i],
        raster: res.raster,
        class: res.class
      }));

      // =========================
      // ✅ DRAW GRAPH
      // =========================
      this.drawMultiBarChart(chartArray);

      // =========================
      // ✅ CSV EXPORT
      // =========================
      let csv = 'Unit,Area,Raster,ForestClass\n';

      chartArray.forEach(row => {
        csv += `${row.label},${row.area.toFixed(2)},${row.raster},${row.class}\n`;
      });
      console.log(csv);
    });

    this.updateLayerVisibility(layerName);
  }
  async generateGISReportPDF() {
    const finalData: any[] = [];
    const promises: Promise<any>[] = [];

    // ==========================================
    // 1. DATA COLLECTION (Existing Logic)
    // ==========================================
    Object.keys(this.adminLayerRefs).forEach(layerName => {
      const layerRef = this.adminLayerRefs[layerName];
      const propKey = this.propertyMap[layerName];
      const selections = this.subUnitSelections[layerName];

      if (!layerRef || !propKey || !selections) return;

      layerRef.eachLayer((layer: any) => {
        const props = layer.feature?.properties || {};
        const unitName = props[propKey];
        const isVisible = selections[unitName];

        if (!isVisible) return;

        const area = Number(props.Area_sqkm) || 0;
        const center = layer.getBounds().getCenter();

        promises.push(
          this.getRasterValueAtPoint(center, unitName).then((res) => {
            finalData.push({
              unit: unitName,
              layer: layerName,
              area: area.toFixed(2),
              raster: res.raster,
              forestClass: res.class,
              ...props
            });
          })
        );
      });
    });

    await Promise.all(promises);

    // ==========================================
    // 2. CAPTURE MAP & CHARTS AS IMAGES
    // ==========================================

    // Capture the Map
    const mapElement = document.getElementById('map') as HTMLElement;
    const mapCanvas = await html2canvas(mapElement, {
      useCORS: true, // Crucial for loading map tiles in the screenshot
      allowTaint: true,
      logging: false
    });
    const mapImgData = mapCanvas.toDataURL('image/png');

    // Capture the Bar Chart Canvas
    const barImgData = this.barCanvas.nativeElement.toDataURL('image/png');

    // Capture the Pie Chart Canvas
    const pieImgData = this.pieCanvas.nativeElement.toDataURL('image/png');

    // ==========================================
    // 3. GENERATE PDF
    // ==========================================
    const doc = new jsPDF('landscape');

    // --- Page 1: Title & Map ---
    doc.setFontSize(20);
    doc.setTextColor(27, 94, 32); // Forest Green
    doc.text('GIS FOREST DETAIL ANALYSIS REPORT', 14, 15);

    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 22);

    doc.setFontSize(14);
    doc.setTextColor(0);
    doc.text('Spatial Analysis View (Map)', 14, 35);
    // addImage(img, format, x, y, width, height)
    doc.addImage(mapImgData, 'PNG', 14, 40, 270, 130);

    // --- Page 2: Detailed Data Table ---
    doc.addPage();
    doc.text('Attribute Data Breakdown', 14, 15);

    const headers = ['unit', 'layer', 'area', 'raster', 'forestClass'];
    const tableData = finalData.map(row => headers.map(h => String(row[h] ?? '')));

    autoTable(doc, {
      startY: 20,
      head: [headers.map(h => h.toUpperCase())],
      body: tableData,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [27, 94, 32] }
    });

    // --- Page 3: Graphs & Summary ---
    doc.addPage();
    doc.setFontSize(16);
    doc.text('STATISTICAL ANALYSIS', 14, 15);

    // Add the Bar Chart
    doc.setFontSize(12);
    doc.text('Forest Class Distribution (Bar Chart)', 14, 30);
    doc.addImage(barImgData, 'PNG', 14, 35, 130, 80);

    // Add the Pie Chart
    doc.text('Percentage Composition (Pie Chart)', 155, 30);
    doc.addImage(pieImgData, 'PNG', 155, 35, 120, 80);

    // Summary Text at the bottom
    const totalArea = finalData.reduce((sum, d) => sum + Number(d.area || 0), 0);
    const yPos = 130;
    doc.setFontSize(14);
    doc.text('Summary Information', 14, yPos);
    doc.setFontSize(11);
    doc.text(`Total Analyzed Area: ${totalArea.toFixed(2)} sq.km`, 14, yPos + 10);
    doc.text(`Total Records: ${finalData.length}`, 14, yPos + 18);

    // =========================
    // 4. DOWNLOAD PDF
    // =========================
    doc.save(`GIS_Forest_Report_${new Date().getTime()}.pdf`);
  }
  drawMultiBarChart(data: any[]) {
    const canvas = this.barCanvas.nativeElement;
    const ctx = canvas.getContext('2d')!;

    if (!data || data.length === 0) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      return;
    }

    // ✅ Dynamic width (important for label visibility)
    const barGroupWidth = 80;
    canvas.width = Math.max(700, data.length * barGroupWidth);

    const W = canvas.width;
    const H = canvas.height = 320;

    ctx.clearRect(0, 0, W, H);

    const padding = 60;
    const barWidth = 20;

    const max = Math.max(
      ...data.map(d => Math.max(d.area, d.raster)),
      1
    );

    // =========================
    // ✅ GRID
    // =========================
    ctx.strokeStyle = '#eee';
    ctx.fillStyle = '#666';
    ctx.font = '11px Arial';

    const steps = 5;
    for (let i = 0; i <= steps; i++) {
      const y = H - padding - (i / steps) * (H - padding * 2);

      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(W - 20, y);
      ctx.stroke();

      const value = (max * i) / steps;
      ctx.fillText(value.toFixed(2), 5, y + 3); // ✅ decimals
    }

    // =========================
    // ✅ AXIS
    // =========================
    ctx.strokeStyle = '#333';
    ctx.beginPath();
    ctx.moveTo(padding, H - padding);
    ctx.lineTo(W - 20, H - padding);
    ctx.stroke();

    // =========================
    // ✅ BARS + LABELS
    // =========================
    data.forEach((item, i) => {
      const x = padding + i * barGroupWidth;

      const areaHeight = (item.area / max) * (H - padding * 2);
      const rasterHeight = (item.raster / max) * (H - padding * 2);

      const y1 = H - padding - areaHeight;
      const y2 = H - padding - rasterHeight;

      // 🟩 AREA BAR
      ctx.fillStyle = '#4CAF50';
      ctx.fillRect(x, y1, barWidth, areaHeight);

      // 🟦 RASTER BAR
      ctx.fillStyle = '#2196F3';
      ctx.fillRect(x + barWidth + 6, y2, barWidth, rasterHeight);

      // =========================
      // ✅ VALUE TEXT (DECIMALS)
      // =========================
      ctx.fillStyle = '#000';
      ctx.font = '11px Arial';
      ctx.textAlign = 'center';

      ctx.fillText(item.area.toFixed(2), x + barWidth / 2, y1 - 6);
      ctx.fillText(item.raster.toFixed(2), x + barWidth + 6 + barWidth / 2, y2 - 6);

      // =========================
      // ✅ LABEL (VISIBLE + WRAPPED)
      // =========================
      const label = item.label;

      ctx.save();
      ctx.translate(x + barWidth, H - 10);
      ctx.rotate(-Math.PI / 8); // less tilt → more readable

      ctx.fillStyle = '#222';
      ctx.font = '11px Arial';

      // 👇 wrap long names
      const maxLength = 10;
      const lines = label.match(new RegExp('.{1,' + maxLength + '}', 'g'));

      if (lines) {
        lines.forEach((line: string, idx: number) => {
          ctx.fillText(line, 0, idx * 12);
        });
      }

      ctx.restore();
    });

    // =========================
    // ✅ LEGEND
    // =========================
    ctx.fillStyle = '#4CAF50';
    ctx.fillRect(W - 160, 10, 12, 12);
    ctx.fillStyle = '#000';
    ctx.fillText('Area', W - 140, 20);

    ctx.fillStyle = '#2196F3';
    ctx.fillRect(W - 160, 30, 12, 12);
    ctx.fillStyle = '#000';
    ctx.fillText('Raster', W - 140, 40);
  }

  getRasterValueAtPoint(latlng: any, label: string): Promise<any> {
    return new Promise((resolve) => {

      const point = this.map.latLngToContainerPoint(latlng);
      const size = this.map.getSize();

      let wmsLayer: any = null;

      // ✅ Find correct WMS layer
      this.map.eachLayer((layer: any) => {
        if (
          layer._url &&
          layer.wmsParams &&
          layer.wmsParams.layers === this.layerName // 👈 change if needed
        ) {
          wmsLayer = layer;
        }
      });

      if (!wmsLayer) {
        resolve({ label, raster: 0, class: '' });
        return;
      }

      const url = `
${wmsLayer._url}
?service=WMS
&version=1.1.1
&request=GetFeatureInfo
&layers=${wmsLayer.wmsParams.layers}
&query_layers=${wmsLayer.wmsParams.layers}
&bbox=${this.map.getBounds().toBBoxString()}
&height=${size.y}
&width=${size.x}
&info_format=application/json
&srs=EPSG:4326
&x=${Math.floor(point.x)}
&y=${Math.floor(point.y)}
`;

      this.http.get(url).subscribe((res: any) => {

        let rasterValue = 0;
        let forestClass = '';

        if (res?.features?.length > 0) {
          const props = res.features[0].properties;

          rasterValue = Number(
            props.GRAY_INDEX ??
            props.value ??
            props.Band1 ??
            0
          );

          // 🌲 CLASSIFICATION
          if (rasterValue >= 60) {
            forestClass = 'Very Dense Forest';
          } else if (rasterValue >= 30) {
            forestClass = 'Moderate Forest';
          } else {
            forestClass = 'Open Forest';
          }
        }

        resolve({
          label,
          raster: rasterValue,
          class: forestClass
        });

      }, () => {
        resolve({ label, raster: 0, class: '' });
      });

    });
  }
  // OPTIONAL: Select or Deselect only the units currently visible via Search
  toggleFilteredSubUnits(layerName: string, isSelected: boolean) {
    const filteredUnits = this.getFilteredUnits(layerName);

    filteredUnits.forEach(unit => {
      this.subUnitSelections[layerName][unit] = isSelected;
    });

    // Apply changes to the map
    this.toggleSubUnitVisibility(layerName);
  }
  zoomToSubUnit(layerName: string, unitName: string) {
    const layerRef = this.adminLayerRefs[layerName]; // The Leaflet GeoJSON layer
    const propKey = this.propertyMap[layerName];    // e.g., 'District_F'

    if (layerRef && propKey) {
      // We use a LatLngBounds object to handle Multi-polygons 
      // (In case one district has multiple separate shapes)
      const bounds = L.latLngBounds([]);
      let found = false;

      layerRef.eachLayer((layer: any) => {
        // Check if this feature matches the name we clicked
        if (layer.feature.properties[propKey] === unitName) {
          if (layer.getBounds) {
            bounds.extend(layer.getBounds());
            found = true;
          } else if (layer.getLatLng) {
            // If it's a point (marker) instead of a polygon
            bounds.extend(layer.getLatLng());
            found = true;
          }
        }
      });

      if (found) {
        // Zoom the map to the calculated boundary
        // padding: [20, 20] adds a small margin around the area
        this.map.fitBounds(bounds, {
          padding: [30, 30],
          maxZoom: 14,
          animate: true
        });
      }
    }
  }

  private toggleChildrenRecursive(node: any, isChecked: boolean) {
    if (node.layername) {
      this.checkedStates[node.id] = isChecked;
      this.onLayerToggle(isChecked, node.layername);
    }
    if (node.children && node.children.length > 0) {
      node.children.forEach((child: any) => {
        this.checkedStates[child.id] = isChecked;
        this.toggleChildrenRecursive(child, isChecked);
      });
    }
  }

  onCollectedDataYearChange(): void {
    if (this.activeCollectedDataLayerName) {
      this.onLayerToggle(false, this.activeCollectedDataLayerName);
    }

    this.activeCollectedDataLayerName = this.selectedCollectedDataYear;

    if (!this.selectedCollectedDataYear) return;

    this.onLayerToggle(true, this.selectedCollectedDataYear);
  }

  onLayerToggle(event: any, layerName: string) {
    const checked: boolean = typeof event === 'boolean' ? event : (event?.target?.checked ?? false);
    if (checked) {
      this.loadLayerByName(layerName);
      if (this.isRasterGraphLayer(layerName)) {
        this.rasterdataonly = true;
        if (!this.isApplyingTimeSeriesSelection) {
          this.syncGraphModeFromRasterLayer(layerName);
        }
      }
    } else {
      const layerObj = this.layerDetailsArray.find(x => x.layername === layerName);
      if (layerObj && this.map.hasLayer(layerObj.layer)) {
        this.map.removeLayer(layerObj.layer);
      }
      if (layerName === this.activeRasterLayerName) {
        this.activeRasterLayerName = '';
        this.rasterSummaryRows = [];
        this.rasterTopStatisticValues = {};
        this.graphSummaryRows = [];
        this.graphTotalArea = 0;
        this.graphMessage = 'Select a raster layer to calculate WMS statistics.';
        this.drawImpactCharts(this.getSelectedYears(), this.getSelectedYears().map(() => 0), []);
      }
    }
  }

  private isRasterGraphLayer(layerName: string): boolean {
    return layerName === "fdsMapRaster"
      || layerName === "fdsMapRasterChangeDetection"
      || layerName === "geojsonCanopyDensity"
      || layerName === "FCDMarch2025"
      || layerName === "geojsonStreams"
      || layerName === "lulcLayer"
      || layerName === "soil_erosion"
      || layerName.startsWith("LULC_Tripura_November_")
      || layerName === "demforestslope"
      || layerName === "geojsonJFMCVegetationType"
      || layerName === "geojsonJFMCForestCover"
      || layerName === "geojsonJFMCLanduse";
  }

  fitToStateBoundary() {
    const stateBoundaryLayer = this.layerDetailsArray.find(layer => layer.layername === 'geojsonLayer');
    if (stateBoundaryLayer && stateBoundaryLayer.layer) {
      try {
        const bounds = (stateBoundaryLayer.layer as any).getBounds();
        if (bounds && bounds.isValid()) {
          this.map.fitBounds(bounds, { padding: [50, 50], maxZoom: 10 });
        }
      } catch (error) { }
    }
  }

  changeBaseMap(type: string) {
    this.activeBaseLayerName = type;

    // 1. Identify and remove only the BASE tile layers
    this.map.eachLayer((layer: any) => {
      // We check if it's a TileLayer BUT ensure it is NOT a WMS layer.
      // Checking for 'wmsParams' is safer than 'instanceof' in some Angular builds.
      if (layer instanceof L.TileLayer && !layer.hasOwnProperty('wmsParams')) {
        this.map.removeLayer(layer);
      }
    });

    // 2. Define the new layer variable
    let selectedLayer: L.TileLayer;

    if (type === 'streets') {
      selectedLayer = this.googleStreets;
    } else if (type === 'satellite') {
      selectedLayer = this.googleSatellite;
    } else if (type === 'terrain') {
      selectedLayer = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
        maxZoom: 17,
        attribution: 'OpenTopoMap'
      });
    } else {
      // Default to OSM
      selectedLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: 'OpenStreetMap'
      });
    }

    // 3. Add to map and FORCE it to the background
    selectedLayer.addTo(this.map);
    selectedLayer.bringToBack(); // <--- THIS IS CRITICAL

    // 4. Optional: If you have WMS layers currently active, 
    // you might need to nudge them to the front if they are still hidden
    this.layerDetailsArray.forEach(item => {
      if (this.map.hasLayer(item.layer)) {
        if (item.layer.bringToFront) {
          item.layer.bringToFront();
        }
      }
    });
  }

  updateOpacity(event: any) {
    this.layerOpacity = event.target.value;
    const opacityVal = this.layerOpacity / 100;
    this.layerDetailsArray.forEach(item => {
      if (item.layer.setOpacity) item.layer.setOpacity(opacityVal);
      else if (item.layer.setStyle) item.layer.setStyle({ fillOpacity: opacityVal, opacity: opacityVal });
    });
  }

  toggleBasemapMenu() {
    this.showBasemapMenu = !this.showBasemapMenu;

  }

  toggleControls() {
    this.isControlsHidden = !this.isControlsHidden;
    this.refreshMapSize();
    this.refreshMapSize(250);
  }

  toggleFcdNovLayer(event: any) {
    this.fcdNov2025Visible = event?.target?.checked ?? false;
    this.onLayerToggle(this.fcdNov2025Visible, 'FCDMarch2025');
    this.fcd = this.fcdNov2025Visible;
  }

  toggleFdsLayer(event: any) {
    this.fdsVisible = event?.target?.checked ?? false;
    this.onLayerToggle(this.fdsVisible, 'fdsMapRaster');
  }

  toggleLulcLayer(event: any) {
    this.lulcVisible = event?.target?.checked ?? false;
    this.onLayerToggle(this.lulcVisible, this.getLulcLayerName(this.selectedLulcYear));
    this.showLulcLegend = this.lulcVisible;
  }

  onLulcYearChange() {
    this.removeLulcLayers();
    if (this.lulcVisible) {
      this.onLayerToggle(true, this.getLulcLayerName(this.selectedLulcYear));
      this.showLulcLegend = true;
    }
  }

  toggleSoilLayer(event: any) {
    this.soilVisible = event?.target?.checked ?? false;
    this.onLayerToggle(this.soilVisible, 'soil_erosion');
  }

  private getLulcLayerName(year: number | string): string {
    return `LULC_Tripura_November_${year}_v5`;
  }

  private removeLulcLayers() {
    this.lulcYears.forEach(year => {
      const layerObj = this.layerDetailsArray.find(x => x.layername === this.getLulcLayerName(year));
      if (layerObj && this.map.hasLayer(layerObj.layer)) {
        this.map.removeLayer(layerObj.layer);
      }
    });
  }

  getYearMonthValue(year: number | string): string {
    return `${year}-01`;
  }

  onCalendarYearChange(type: 'from' | 'to', value: string) {
    const year = Number((value || '').split('-')[0]);
    if (!year) return;

    if (type === 'from') {
      this.selectedFromYear = year;
    } else {
      this.selectedToYear = year;
    }

    this.applyTimeSeriesSelection();
    this.renderImpactStatistics();
  }

  applyTimeSeriesSelection() {
    const fromYear = Math.min(Number(this.selectedFromYear), Number(this.selectedToYear));
    const toYear = Math.max(Number(this.selectedFromYear), Number(this.selectedToYear));
    this.selectedFromYear = fromYear;
    this.selectedToYear = toYear;

    this.clearActiveTimeSeriesLayers();

    const layerNames = this.getTimeSeriesLayerNames(fromYear, toYear);
    this.isApplyingTimeSeriesSelection = true;
    try {
      layerNames.forEach(layerName => {
        this.onLayerToggle(true, layerName);
        this.activeTimeSeriesLayers.push(layerName);
      });
    } finally {
      this.isApplyingTimeSeriesSelection = false;
    }

    this.syncTimeSeriesToggleState(layerNames);
    this.showLulcLegend = this.lulcVisible;
    this.showChangeDetectionLegend = this.fdsVisible;
    this.fcd = this.fcdNov2025Visible;

    const graphLayerName = layerNames[layerNames.length - 1];
    if (graphLayerName) {
      this.syncGraphModeFromRasterLayer(graphLayerName);
    } else {
      this.activeRasterLayerName = '';
      this.graphMessage = `No WMS raster layer is configured for ${this.selectedTimeSeriesLayer} in ${fromYear} - ${toYear}.`;
      this.graphSummaryRows = [];
      this.graphTotalArea = 0;
      this.rasterTopStatisticValues = {};
      this.drawImpactCharts(this.getSelectedYears(), this.getSelectedYears().map(() => 0), []);
    }
  }

  private clearActiveTimeSeriesLayers() {
    this.activeTimeSeriesLayers.forEach(layerName => {
      const layerObj = this.layerDetailsArray.find(x => x.layername === layerName);
      if (layerObj && this.map.hasLayer(layerObj.layer)) {
        this.map.removeLayer(layerObj.layer);
      }
    });
    this.activeTimeSeriesLayers = [];
  }

  private getTimeSeriesLayerNames(fromYear: number, toYear: number): string[] {
    const layerNames = new Set<string>();

    for (let year = fromYear; year <= toYear; year++) {
      switch (this.selectedTimeSeriesLayer) {
        case 'FCD':
          if (year <= 2023) layerNames.add('geojsonCanopyDensity');
          if (year >= 2025) layerNames.add('FCDMarch2025');
          if (fromYear <= 2023 && toYear >= 2025) layerNames.add('fdsMapRasterChangeDetection');
          break;

        case 'FDS':
          layerNames.add(year >= 2025 ? 'fdsMapRasterChangeDetection' : 'fdsMapRaster');
          break;

        case 'LULC':
          if (this.lulcYears.includes(year)) {
            layerNames.add(this.getLulcLayerName(year));
          }
          break;

        case 'SOIL':
          layerNames.add('soil_erosion');
          break;
      }
    }

    return Array.from(layerNames);
  }

  private syncTimeSeriesToggleState(layerNames: string[]) {
    this.fcdNov2025Visible = layerNames.includes('FCDMarch2025') || layerNames.includes('geojsonCanopyDensity');
    this.fdsVisible = layerNames.includes('fdsMapRaster') || layerNames.includes('fdsMapRasterChangeDetection');
    this.lulcVisible = layerNames.some(layerName => layerName.startsWith('LULC_Tripura_November_'));
    this.soilVisible = layerNames.includes('soil_erosion');

    const firstLulc = layerNames.find(layerName => layerName.startsWith('LULC_Tripura_November_'));
    const yearMatch = firstLulc?.match(/_(\d{4})_v5$/);
    if (yearMatch) {
      this.selectedLulcYear = Number(yearMatch[1]);
    }
  }

  toggleStateBoundaryLayer(event: any) {
    this.stateBoundaryVisible = event?.target?.checked ?? false;
    this.checkedStates['j1_1'] = this.stateBoundaryVisible;
    this.onLayerToggle(this.stateBoundaryVisible, 'geojsonLayer');
    if (this.stateBoundaryVisible) {
      this.updateBoundaryLayerStyle();
      this.fitToStateBoundary();
    }
  }

  updateBoundaryLayerStyle() {
    const opacity = Number(this.selectedBoundaryOpacity) / 100;
    const style = {
      color: this.selectedBoundaryBorderColor,
      weight: Number(this.selectedBoundaryBorderWidth),
      fillColor: this.selectedBoundaryFillColor,
      fillOpacity: opacity * 0.16,
      opacity
    };

    ['geojsonLayer', 'geojsonDistrict', 'geojsonSubDivision', 'geojsonforestRange', 'geojsonBeat'].forEach(layerName => {
      const layerRef = this.adminLayerRefs[layerName];
      if (!layerRef?.eachLayer) return;
      layerRef.eachLayer((layer: any) => {
        if (layer?.options?.opacity > 0 || layerName === 'geojsonLayer') {
          layer.setStyle(style);
        }
      });
    });
  }






  showImpactPanel: boolean = true;
  isImpactMinimized: boolean = false;

  // Your Layer Data (Matching your image colors)
  // impactLayerList: ImpactLayer[] = [
  //   { name: 'FCD March 2023', visible: false },
  //   { name: 'FCD March 2025', visible: false },
  //   { name: 'FCD Change Detection 2023-2025', visible: false },
  // ];`


  // Toggle the switch for a specific layer
  toggleImpactLayer(layer: any, event: any) {

    // ✅ checkbox state
    const isChecked = event.target.checked;
    layer.visible = isChecked;

    console.log(layer.text, isChecked ? 'ON' : 'OFF');

    // =========================
    // 🧹 REMOVE OLD LAYER
    // =========================
    if (this.activeImpactLayer) {
      this.map.removeLayer(this.activeImpactLayer);
      this.activeImpactLayer = null;
    }

    // =========================
    // 🔁 ONLY ONE ACTIVE (optional but useful)
    // =========================
    if (!this.isYearSelection) {
      this.impactLayerList.forEach(parent => {
        parent.children.forEach(child => {
          if (child !== layer) child.visible = false;
        });
      });
    }

    // =========================
    // ❌ IF UNCHECK → EXIT
    // =========================
    if (!isChecked) {
      this.legendData = [];
      this.showCharts = false;
      return;
    }

    // =========================
    // 🎯 MAP LAYER MAPPING
    // =========================
    let layerName = '';

    switch (layer.text) {

      case 'FCD Change Detection 2020':
        layerName = 'geojsonCanopyDensity';
        this.fcd = true;
        this.selectedLayer = '2023';
        break;

      case 'FDS Change Detection 2020':
        layerName = 'fdsMapRaster';
        break;

      case 'LULC Change Detection 2020':
        layerName = 'LULC_Tripura_November_2020_v5';
        this.showLulcLegend = true;
        break;
      case 'LULC Change Detection 2021':
        layerName = 'LULC_Tripura_November_2021_v5';
        this.showLulcLegend = true;
        break;
      case 'LULC Change Detection 2022':
        layerName = 'LULC_Tripura_November_2022_v5';
        this.showLulcLegend = true;
        break;
      case 'LULC Change Detection 2023':
        layerName = 'LULC_Tripura_November_2023_v5';
        this.showLulcLegend = true;
        break;
      case 'LULC Change Detection 2024':
        layerName = 'LULC_Tripura_November_2024_v5';
        this.showLulcLegend = true;
        break;
      case 'LULC Change Detection 2025':
        layerName = 'LULC_Tripura_November_2025_v5';
        this.showLulcLegend = true;
        break;


      case 'Soil Moisture Detection':
        layerName = 'soil_erosion';
        break;
    }

    if (!layerName) return;

    // =========================
    // 🚀 LOAD LAYER
    // =========================
    this.loadLayerByName(layerName);
    if (!this.isYearSelection) {
      this.syncGraphModeFromRasterLayer(layerName);
    }

    // store active layer
    const layerObj = this.layerDetailsArray.find(x => x.layername === layerName);
    if (layerObj) {
      this.activeImpactLayer = layerObj.layer;
    }

    // =========================
    // 📊 LEGEND
    // =========================
    const config = this.LAYER_CONFIGS[layer.text];
    if (config) {
      this.legendData = [config];
    }

    // =========================
    // 📊 UI
    // =========================
    this.showDataGrid = true;
    this.reloadGraphs();
    setTimeout(() => {
      this.renderDynamicChart();
    }, 200);
  }
  getChartData() {
    if (this.selectedLayer === '2023') {
      return this.forestChartData.map(d => ({
        label: d.label,
        area23: d.area23,
        area25: 0
      }));
    }

    if (this.selectedLayer === '2025') {
      return this.forestChartData.map(d => ({
        label: d.label,
        area23: 0,
        area25: d.area25
      }));
    }

    return this.forestChartData; // change detection → full data
  }

  toggleParentLayer(parent: any, event: any) {
    const isChecked = event.target.checked;
    this.isYearSelection = true;
    parent.checked = isChecked;
    this.impactlayername = parent.text;
    this.onYearRangeChange();

  }



  // Minimize/Expand the panel
  toggleImpactPanel() {
    this.isImpactMinimized = !this.isImpactMinimized;
  }

  // Close the panel completely
  closeImpactPanel() {
    this.showImpactPanel = false;
  }


  // Modify toggleGrid to initialize charts after a small delay to ensure Canvas is in DOM
  toggleGrid() {
    this.showDataGrid = !this.showDataGrid;
    if (this.showDataGrid) {
      setTimeout(() => {
        this.initDashboardCharts();
      }, 100);
    }
  }
  // Add these properties to your class




  // Add this function to create the charts
  initDashboardCharts() {
    // Destroy existing charts if they exist to prevent memory leaks/overlap
    if (this.barChart) this.barChart.destroy();
    if (this.lineChart) this.lineChart.destroy();

    // 1. Bar Chart (Gradation Value)
    const barCtx = document.getElementById('barChartCanvas') as HTMLCanvasElement;
    this.barChart = new Chart(barCtx, {
      type: 'bar',
      data: {
        labels: ['SHG A', 'SHG B', 'SHG C', 'SHG D', 'SHG E'],
        datasets: [{
          label: 'Gradation Value',
          data: [12, 45, 62, 85, 100],
          backgroundColor: ['#ffc107', '#ff9800', '#8bc34a', '#2196f3', '#00bcd4'],
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          y: { grid: { color: '#1a3322' }, ticks: { color: '#888' } },
          x: { ticks: { color: '#888' } }
        }
      }
    });

    // 2. Line Chart (Financial Analysis)
    const lineCtx = document.getElementById('lineChartCanvas') as HTMLCanvasElement;
    this.lineChart = new Chart(lineCtx, {
      type: 'line',
      data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [
          {
            label: 'Series 1',
            data: [12, 19, 3, 5, 2, 3],
            borderColor: '#8bc34a',
            backgroundColor: '#8bc34a',
            tension: 0.4,
            pointRadius: 4
          },
          {
            label: 'Series 2',
            data: [7, 11, 5, 8, 3, 7],
            borderColor: '#2196f3',
            borderDash: [5, 5],
            tension: 0.4,
            pointRadius: 4
          }
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { labels: { color: '#fff', boxWidth: 10 } } },
        scales: {
          y: { grid: { color: '#1a3322' }, ticks: { color: '#888' } },
          x: { ticks: { color: '#888' } }
        }
      }
    });
  }

  gridData = [
    { status: 'John Douey', group: '-', scheme: '-', type: '-', year: '2023-24' },
    { status: 'John Douey', group: '-', scheme: '-', type: '-', year: '2023-24' },
    { status: 'John', group: '-', scheme: '-', type: '-', year: '2022-23' }
  ];

  closecharts() {
    this.showCharts = false;
    this.showImpactPanel = true;
    this.isImpactMinimized = false;
  }

  // Add these to your class properties
  siteAnalysisData = {
    id: 'Forest Site 202',
    type: 'Moist Tropical',
    primarySpecies: 'Mahogany',
    carbonStock: 23,
    health: 'Excellent'
  };

  // State for the "Change" section toggles
  changeSectionToggles = {
    fcd: false,
    fds: true,
    lulc: true,
    soil: true
  };

  // Mapping "Change" section to your existing layer names
  toggleChangeLayer(type: string, event: any) {
    const isChecked = event.target.checked;
    let layerName = '';

    switch (type) {
      // this.showChangeDetectionLegend = false
      case 'FCD Change Detection': layerName = 'fdsMapRasterChangeDetection'; this.showChangeDetectionLegend = true; break;
      case 'FCD March 2025': layerName = 'FCDMarch2025'; this.fcd = true; this.showChangeDetectionLegend = false; break;
      case 'FCD Change Detection 2023-2025': layerName = 'fdsMapRasterChangeDetection'; this.showChangeDetectionLegend = true; this.fcd = false; break;
    }

    if (layerName) {
      this.onLayerToggle(isChecked, layerName);
    }
  }

  // Logic for the Comparison Dropdowns
  onVersionChange() {
    console.log(`Comparing ${this.selectedVersionA} with ${this.selectedVersionB}`);
    // Example: Trigger the slider between two specific years
    this.toggleSlider('geojsonCanopyDensity', 'FCDMarch2025');
  }
  // ✅ Returns true if ALL sub-units of a layer are selected
  areAllSubUnitsSelected(layerName: string): boolean {
    const units = this.subUnitLists[layerName];
    const selections = this.subUnitSelections[layerName];
    if (!units || units.length === 0 || !selections) return false;
    return units.every(unit => selections[unit] === true);
  }

  // ✅ Returns true if SOME but not all are selected → shows indeterminate (dash) state
  areSomeSubUnitsSelected(layerName: string): boolean {
    const units = this.subUnitLists[layerName];
    const selections = this.subUnitSelections[layerName];
    if (!units || units.length === 0 || !selections) return false;
    const selectedCount = units.filter(unit => selections[unit] === true).length;
    return selectedCount > 0 && selectedCount < units.length;
  }
  updateLayerVisibility(layerName: string) {
    const units = this.subUnitLists[layerName];
    const selections = this.subUnitSelections[layerName];

    if (!units || !selections) return;

    units.forEach(unit => {
      const layerKey = `${layerName}_${unit}`;
      const layerObj = this.layerDetailsArray.find(l => l.layername === layerKey);

      if (!layerObj) return;

      if (selections[unit]) {
        // ✅ SHOW layer
        if (!this.map.hasLayer(layerObj.layer)) {
          this.map.addLayer(layerObj.layer);
        }
      } else {
        // ❌ HIDE layer
        if (this.map.hasLayer(layerObj.layer)) {
          this.map.removeLayer(layerObj.layer);
        }
      }
    });
  }

  // ✅ NEW: Initialize Year Range (10 years)
  initializeYearRange(): void {
    this.yearRange = [];
    const latestAvailableYear = Math.max(2025, ...this.lulcYears);
    const firstYear = latestAvailableYear - 9;

    this.baseYear = firstYear;
    this.selectedFromYear = firstYear;
    this.selectedToYear = latestAvailableYear;

    for (let year = firstYear; year <= latestAvailableYear; year++) {
      this.yearRange.push(year);
    }
  }
  

  // ✅ NEW: Handle Year Range Change
  onYearRangeChange(): void {

    if (
      this.isYearSelection &&
      ['FCD Layers', 'FDS Layers', 'LULC Layers', 'Soil Layers']
        .includes(this.impactlayername)
    ) {

  this.impactLayerList.forEach(parent => {

    // ✅ Only apply to selected parent
    if (parent.text !== this.impactlayername) return;

    let anyChecked = false;

    parent.children.forEach((child: any) => {

      const match = child.text.match(/\d{4}/);
      const year = match ? Number(match[0]) : null;

      if (
        year &&
        year >= this.selectedFromYear &&
        year <= this.selectedToYear
      ) {
        child.visible = true;
        child.checked = true; // ✅ important
        anyChecked = true;

        this.toggleImpactLayer(child, { target: { checked: true } });

      } else {
        child.visible = false;
        child.checked = false;
      }

    });

    parent.checked = anyChecked;

  });
}
    this.reloadGraphs();
  }


  loadRasterByYear() {
    if (this.currentRasterLayer) {
      this.map.removeLayer(this.currentRasterLayer);
    }

    this.currentRasterLayer = L.tileLayer.wms(
      this.service.Geoserver_URl,
      {
        layers: 'ws_figs:your_layer_name',
        format: 'image/png',
        transparent: true,
        TIME: `${this.selectedFromYear}-01-01/${this.selectedToYear}-12-31`,
        _t: new Date().getTime()
      } as any
    );

    console.log('Loading raster for years:', this.selectedFromYear, 'to', this.selectedToYear);
    this.map.on('click', (e: any) => {
      this.getRasterInfo(e.latlng);
    });

    this.map.addLayer(this.currentRasterLayer);
  }

  getRasterInfo(latlng: any) {

    const point = this.map.latLngToContainerPoint(latlng);
    const size = this.map.getSize();

    const baseUrl = this.service.Geoserver_URl + '/geoserver/ws_figs/wms';

    const layerFullName = `ws_figs:${this.actuallayername}`;

    const params: any = {
      service: 'WMS',
      request: 'GetFeatureInfo',
      version: '1.1.1',

      layers: layerFullName,
      query_layers: layerFullName,

      info_format: 'application/json',
      format: 'image/png',
      transparent: true,

      srs: 'EPSG:4326',
      bbox: this.map.getBounds().toBBoxString(),

      width: size.x,
      height: size.y,

      x: Math.floor(point.x),
      y: Math.floor(point.y)
    };

    // ✅ SAFE FILTER (only if field exists)
    if (this.selectedFromYear && this.selectedToYear) {
      params.CQL_FILTER = `yr >= ${this.selectedFromYear} AND yr <= ${this.selectedToYear}`;
    }

    const url = baseUrl + L.Util.getParamString(params);

    console.log('GetFeatureInfo URL:', url);

    this.http.get(url).subscribe({
      next: (res: any) => {
        console.log('Raster/Layer Info:', res);

        if (res?.features?.length) {
          const data = res.features[0].properties;

          L.popup()
            .setLatLng(latlng)
            .setContent(`<pre>${JSON.stringify(data, null, 2)}</pre>`)
            .openOn(this.map);

        } else {
          L.popup()
            .setLatLng(latlng)
            .setContent('No data available')
            .openOn(this.map);
        }
      },
      error: (err) => {
        console.error('GetFeatureInfo Error:', err);
      }
    });
  }
  reloadGraphs(): void {
    console.log('Reloading graphs for year range');
    if (this.barChart) {
      this.barChart.destroy();
      this.barChart = null;
    }
    if (this.lineChart) {
      this.lineChart.destroy();
      this.lineChart = null;
    }
    // Reload chart data based on selected years
  }

  // ✅ NEW: Switch Map View (OSM / Satellite)
  setMapView(viewType: string): void {
    this.mapViewType = viewType;

    if (!this.map) return;

    // ✅ Remove all existing tile layers
    this.map.eachLayer((layer: any) => {
      if (layer instanceof L.TileLayer && !layer.hasOwnProperty('wmsParams')) {
        this.map.removeLayer(layer);
      }
    });

    // ✅ Satellite
    if (viewType === 'satellite') {
      if (this.googleSatellite) {
        this.googleSatellite.addTo(this.map);
      }
      this.activeBaseLayerName = 'Satellite';
    }

    // ✅ Google Streets
    else if (viewType === 'street') {
      if (!this.googleStreets) {
        this.googleStreets = L.tileLayer(
          'https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
          {
            maxZoom: 20,
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
            attribution: 'Google Streets'
          }
        );
      }

      this.googleStreets.addTo(this.map); // 🔥 IMPORTANT
      this.activeBaseLayerName = 'Google Streets';
    }

    // ✅ OSM Default
    else {
      const osm = L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        {
          attribution: 'OpenStreetMap',
          maxZoom: 19
        }
      );

      osm.addTo(this.map);
      this.activeBaseLayerName = 'OpenStreetMap';
    }
  }



}
interface ImpactLayer {
  name: string;
  visible: boolean;
}
